import re

APP_PATH = "/Users/burakakcan/.gemini/antigravity/scratch/yks_platform/frontend/app.js"

with open(APP_PATH, "r", encoding="utf-8") as f:
    raw_code = f.read()

lines = raw_code.splitlines()

# 1. Collect all declared function names
declared_funcs = set()
for idx, line in enumerate(lines, 1):
    m = re.finditer(r'(?:async\s+)?function\s+([a-zA-Z0-9_$]+)', line)
    for match in m:
        declared_funcs.add(match.group(1))
    m2 = re.finditer(r'(?:const|let|var|window\.)([a-zA-Z0-9_$]+)\s*=\s*(?:async\s*)?\(', line)
    for match in m2:
        declared_funcs.add(match.group(1))

# Built-ins
builtins = {
    'alert', 'confirm', 'prompt', 'console', 'parseInt', 'parseFloat', 'isNaN', 'isFinite',
    'encodeURIComponent', 'decodeURIComponent', 'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval',
    'fetch', 'location', 'document', 'window', 'localStorage', 'sessionStorage', 'navigator',
    'Math', 'Date', 'JSON', 'Object', 'Array', 'String', 'Number', 'Boolean', 'RegExp', 'Error',
    'Promise', 'Set', 'Map', 'URL', 'URLSearchParams', 'FormData', 'Blob', 'File', 'FileReader',
    'Event', 'CustomEvent', 'Element', 'HTMLElement', 'Image', 'Audio', 'lucide', 'Chart', 'Swal',
    'preventDefault', 'stopPropagation', 'toggle', 'switch', 'closeModal', 'openModal', 'get', 'set'
}

all_known = declared_funcs.union(builtins)

# 2. Extract function calls in event attributes (onclick="...", onchange="...", etc.)
event_calls = []
for idx, line in enumerate(lines, 1):
    for m in re.finditer(r'on[a-z]+\s*=\s*["\']\s*(?:javascript:)?([^"\'\n>]+)["\']', line):
        expr = m.group(1).strip()
        for call in re.findall(r'([a-zA-Z0-9_$]+)\s*\(', expr):
            if call not in all_known and call not in {'return', 'event', 'this'}:
                event_calls.append((idx, call, expr, line.strip()))

# 3. Extract function calls in JS code: fn(...)
js_calls = []
for idx, line in enumerate(lines, 1):
    # Ignore comments
    clean = re.sub(r'//.*', '', line)
    clean = re.sub(r'\'[^\']*\'|"[^"]*"', '', clean)
    
    # Ignore HTML template lines
    if re.search(r'^\s*<', clean) or re.search(r'^\s*//', line):
        continue
        
    for m in re.finditer(r'(?<!\.)\b([a-zA-Z0-9_$]+)\s*\(', clean):
        fn = m.group(1)
        if fn in {'if', 'while', 'for', 'switch', 'catch', 'function', 'async', 'return', 'typeof', 'import', 'export', 'require', 'super'}:
            continue
        if fn not in all_known:
            # check if defined locally in same function
            js_calls.append((idx, fn, line.strip()))

print("=== UNDEFINED FUNCTIONS IN EVENT HANDLERS ===")
for l_num, fn, expr, line_str in event_calls:
    print(f"L{l_num}: '{fn}' in `{expr}`")

print("\n=== UNDEFINED FUNCTIONS IN JS CODE ===")
seen = set()
for l_num, fn, line_str in js_calls:
    if fn not in seen:
        print(f"L{l_num}: '{fn}' -> {line_str}")
        seen.add(fn)

