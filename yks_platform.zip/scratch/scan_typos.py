import re

APP_PATH = "/Users/burakakcan/.gemini/antigravity/scratch/yks_platform/frontend/app.js"

with open(APP_PATH, "r", encoding="utf-8") as f:
    raw_code = f.read()

lines = raw_code.splitlines()

# Extract all word tokens in JS code excluding string literals and comments
clean_lines = []
for line in lines:
    clean = re.sub(r'//.*', '', line)
    clean = re.sub(r'\'[^\']*\'|"[^"]*"|`[^`]*`', '', clean)
    clean_lines.append(clean)

words_freq = {}
word_lines = {}

for idx, clean in enumerate(clean_lines, 1):
    tokens = re.findall(r'\b[a-zA-Z_$][a-zA-Z0-9_$]*\b', clean)
    for t in tokens:
        if len(t) > 3: # focus on identifiers longer than 3 chars
            words_freq[t] = words_freq.get(t, 0) + 1
            if t not in word_lines:
                word_lines[t] = []
            word_lines[t].append(idx)

# Find words that occur only once and look suspiciously like a typo of a frequent word (Levenshtein distance == 1 or double letter)
def levenshtein_1(s1, s2):
    if abs(len(s1) - len(s2)) > 1:
        return False
    if s1 == s2:
        return False
    # Check single character insertion, deletion, or substitution
    if len(s1) == len(s2):
        diffs = sum(1 for a, b in zip(s1, s2) if a != b)
        return diffs == 1
    elif len(s1) == len(s2) + 1:
        for i in range(len(s1)):
            if s1[:i] + s1[i+1:] == s2:
                return True
        return False
    elif len(s2) == len(s1) + 1:
        for i in range(len(s2)):
            if s2[:i] + s2[i+1:] == s1:
                return True
        return False
    return False

suspicious_typos = []

frequent_words = {w for w, freq in words_freq.items() if freq >= 3}
single_words = {w for w, freq in words_freq.items() if freq == 1}

# Filter out common JS builtins/HTML keywords
keywords_ignore = {
    'undefined', 'null', 'true', 'false', 'function', 'return', 'const', 'let', 'async',
    'await', 'class', 'extends', 'super', 'constructor', 'typeof', 'instanceof',
    'document', 'window', 'localStorage', 'sessionStorage', 'location', 'console',
    'alert', 'confirm', 'prompt', 'fetch', 'parseInt', 'parseFloat', 'Math', 'Date',
    'JSON', 'Object', 'Array', 'String', 'Number', 'Boolean', 'RegExp', 'Error',
    'Promise', 'Set', 'Map', 'URL', 'FormData', 'Blob', 'File', 'FileReader', 'Event',
    'CustomEvent', 'Element', 'HTMLElement', 'Image', 'Audio', 'lucide', 'Chart', 'Swal',
    'innerHTML', 'textContent', 'value', 'id', 'type', 'name', 'class', 'style',
    'flex', 'grid', 'text', 'bg', 'border', 'rounded', 'font', 'shadow', 'hover'
}

for sw in single_words:
    if sw in keywords_ignore:
        continue
    for fw in frequent_words:
        if len(sw) >= 5 and levenshtein_1(sw.lower(), fw.lower()):
            line_n = word_lines[sw][0]
            line_str = lines[line_n - 1].strip()
            suspicious_typos.append((line_n, sw, fw, words_freq[fw], line_str))

print(f"Total suspicious typos detected: {len(suspicious_typos)}")
for line_n, sw, fw, freq, line_str in suspicious_typos:
    print(f"L{line_n}: '{sw}' (used 1x) vs '{fw}' (used {freq}x) -> {line_str}")

