import re
import sys

APP_PATH = "/Users/burakakcan/.gemini/antigravity/scratch/yks_platform/frontend/app.js"

with open(APP_PATH, "r", encoding="utf-8") as f:
    raw_code = f.read()

lines = raw_code.splitlines()

def remove_comments_and_strings(code):
    """
    Replaces string literals and comments with spaces, preserving line breaks and character positions.
    """
    result = []
    i = 0
    length = len(code)
    
    while i < length:
        # Single line comment
        if code[i:i+2] == '//':
            start = i
            while i < length and code[i] != '\n':
                i += 1
            result.append(' ' * (i - start))
        # Multi line comment
        elif code[i:i+2] == '/*':
            start = i
            i += 2
            while i < length and code[i:i+2] != '*/':
                if code[i] == '\n':
                    result.append('\n')
                else:
                    result.append(' ')
                i += 1
            if i < length:
                i += 2 # skip */
            result.append(' ' * (i - start - result.count('\n')))
        # Double quote string
        elif code[i] == '"':
            start = i
            i += 1
            while i < length and code[i] != '"':
                if code[i] == '\\':
                    i += 1
                if code[i] == '\n':
                    result.append('\n')
                else:
                    result.append(' ')
                i += 1
            if i < length:
                i += 1
            result.append(' ' * (i - start - result.count('\n')))
        # Single quote string
        elif code[i] == "'":
            start = i
            i += 1
            while i < length and code[i] != "'":
                if code[i] == '\\':
                    i += 1
                if code[i] == '\n':
                    result.append('\n')
                else:
                    result.append(' ')
                i += 1
            if i < length:
                i += 1
            result.append(' ' * (i - start - result.count('\n')))
        # Template literal (approximate - skip static parts)
        elif code[i] == '`':
            start = i
            i += 1
            while i < length and code[i] != '`':
                if code[i] == '\\':
                    i += 1
                elif code[i:i+2] == '${':
                    # Keep JS expressions inside ${...}
                    result.append('  ')
                    i += 2
                    break
                if code[i] == '\n':
                    result.append('\n')
                else:
                    result.append(' ')
                i += 1
            if i < length and code[i] == '`':
                i += 1
                result.append(' ')
        else:
            result.append(code[i])
            i += 1
            
    return "".join(result)

clean_code = remove_comments_and_strings(raw_code)
clean_lines = clean_code.splitlines()

print("Clean code generated without comments/string literals.")

