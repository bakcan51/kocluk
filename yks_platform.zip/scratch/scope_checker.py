import re
import sys

APP_PATH = "/Users/burakakcan/.gemini/antigravity/scratch/yks_platform/frontend/app.js"

with open(APP_PATH, "r", encoding="utf-8") as f:
    raw_code = f.read()

lines = raw_code.splitlines()

# 1. Collect all declared functions (global & local) and top-level variables
globals_declared = {
    'API_BASE', 'currentUser', 'currentView', 'selectedStudentId', 'coachStudentsList',
    'activeResourceSubjectFilter', 'activeResourceSubTab', 'currentKaynakTab',
    'kaynakSearchQuery', 'kaynakSubjectFilter', 'kaynakSystemFilter', 'kaynakTypeFilter',
    'selectedDenemeAttemptId', 'currentMessageRecipientId', 'weeklyActiveStudentId',
    'mufredatActiveStudentId', 'lucide', 'Swal', 'Chart', 'feather', 'bootstrap',
    'window', 'document', 'localStorage', 'sessionStorage', 'console', 'alert', 'confirm',
    'prompt', 'fetch', 'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval',
    'parseInt', 'parseFloat', 'isNaN', 'isFinite', 'encodeURIComponent', 'decodeURIComponent',
    'Math', 'Date', 'JSON', 'Object', 'Array', 'String', 'Number', 'Boolean', 'RegExp', 'Error',
    'Promise', 'Set', 'Map', 'URL', 'URLSearchParams', 'FormData', 'Blob', 'File', 'FileReader',
    'Event', 'CustomEvent', 'Element', 'HTMLElement', 'Image', 'Audio', 'location', 'navigator',
    'event', 'this', 'super', 'self', 'arguments', 'null', 'undefined', 'true', 'false', 'NaN', 'Infinity'
}

# Scan for all top-level functions and variables
for idx, line in enumerate(lines, 1):
    # function declaration
    m_func = re.finditer(r'(?:async\s+)?function\s+([a-zA-Z0-9_$]+)', line)
    for m in m_func:
        globals_declared.add(m.group(1))
    
    # window property assignment
    m_win = re.finditer(r'window\.([a-zA-Z0-9_$]+)\s*=', line)
    for m in m_win:
        globals_declared.add(m.group(1))

    # Top-level var/let/const assignment (lines starting without deep indent)
    m_var = re.finditer(r'^(?:var|let|const)\s+([a-zA-Z0-9_$]+)', line)
    for m in m_var:
        globals_declared.add(m.group(1))

print(f"Total global/top-level symbols identified: {len(globals_declared)}")

# Check for calls to functions in code (e.g. funcName(...))
unresolved_func_calls = []

for idx, line in enumerate(lines, 1):
    clean = re.sub(r'//.*', '', line)
    clean = re.sub(r'\'[^\']*\'|"[^"]*"', '', clean)
    
    # Find all function calls: funcName(...)
    # Exclude property method calls like obj.funcName(...)
    matches = re.finditer(r'(?<!\.)\b([a-zA-Z0-9_$]+)\s*\(', clean)
    for m in matches:
        fn = m.group(1)
        # Exclude JS keywords / control flow structures
        if fn in {'if', 'while', 'for', 'switch', 'catch', 'function', 'async', 'return', 'typeof', 'import', 'export', 'require', 'super'}:
            continue
        if fn not in globals_declared:
            unresolved_func_calls.append((idx, fn, line.strip()))

# Filter out inline anonymous functions or destructured / local function references
real_unresolved = []
for line_num, fn, line_str in unresolved_func_calls:
    # Check if fn is declared locally nearby (up to 50 lines before in same block)
    local_found = False
    start_search = max(0, line_num - 60)
    for check_l in lines[start_search:line_num]:
        if re.search(r'\b(?:const|let|var|function)\s+' + re.escape(fn) + r'\b', check_l):
            local_found = True
            break
        if re.search(r'function\s*\w*\s*\([^)]*\b' + re.escape(fn) + r'\b', check_l):
            local_found = True
            break
    if not local_found:
        real_unresolved.append((line_num, fn, line_str))

print(f"\nFound {len(real_unresolved)} potentially unresolved function calls in JS code:")
seen = set()
for line_num, fn, line_str in real_unresolved:
    if fn not in seen:
        print(f"L{line_num}: '{fn}' -> {line_str}")
        seen.add(fn)

