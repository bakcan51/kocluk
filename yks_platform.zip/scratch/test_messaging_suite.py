import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../backend')))

from backend.app import app

def run_messaging_test_suite():
    print("=" * 60)
    print("🚀 RUNNING 11 AUTOMATED TEST SCENARIOS FOR MESSAGING SYSTEM")
    print("=" * 60)

    client = app.test_client()

    # 1. Login Admin, Coach, Student A, Student B
    admin_login = client.post('/api/login', json={'username': 'admin', 'password': 'password123'}).get_json()
    admin_token = admin_login['token']
    admin_user_id = admin_login['user']['id']
    admin_headers = {'Authorization': f'Bearer {admin_token}'}

    coach_login = client.post('/api/login', json={'username': 'ummu.akcan', 'password': 'password123'}).get_json()
    coach_token = coach_login['token']
    coach_user_id = coach_login['user']['id']
    coach_headers = {'Authorization': f'Bearer {coach_token}'}

    student1_login = client.post('/api/login', json={'username': 'burak.akcan', 'password': 'password123'}).get_json()
    student1_token = student1_login['token']
    student1_user_id = student1_login['user']['id']
    student1_headers = {'Authorization': f'Bearer {student1_token}'}

    student2_login = client.post('/api/login', json={'username': 'mert.demir', 'password': 'password123'}).get_json()
    student2_token = student2_login['token']
    student2_user_id = student2_login['user']['id']
    student2_headers = {'Authorization': f'Bearer {student2_token}'}

    print("🔐 Authenticated Users:")
    print(f"   - ADMIN (id={admin_user_id})")
    print(f"   - COACH (id={coach_user_id})")
    print(f"   - STUDENT 1: Burak (id={student1_user_id})")
    print(f"   - STUDENT 2: Mert (id={student2_user_id})")

    # TEST 1: Admin -> Student
    res1 = client.post('/api/messages', headers=admin_headers, json={
        'receiver_id': student1_user_id,
        'content': 'Merhaba Burak, haftalık programın hazır.'
    })
    assert res1.status_code == 200, f"Test 1 failed: {res1.get_data(as_text=True)}"
    msg1_id = res1.get_json()['id']

    # Verify Student 1 receives message
    s1_msgs = client.get(f'/api/messages/conversations/{admin_user_id}', headers=student1_headers).get_json()['messages']
    found_msg1 = [m for m in s1_msgs if m['id'] == msg1_id]
    assert len(found_msg1) > 0, "Student 1 did not receive Admin's message!"
    print("✅ TEST 1 PASSED: Admin -> Student message delivered successfully.")

    # TEST 2: Student -> Admin
    res2 = client.post('/api/messages', headers=student1_headers, json={
        'receiver_id': admin_user_id,
        'content': 'Teşekkürler hocam, bugün ödevlerimi tamamlayacağım.'
    })
    assert res2.status_code == 200
    msg2_id = res2.get_json()['id']

    adm_msgs = client.get(f'/api/messages/conversations/{student1_user_id}', headers=admin_headers).get_json()['messages']
    found_msg2 = [m for m in adm_msgs if m['id'] == msg2_id]
    assert len(found_msg2) > 0, "Admin did not receive Student's reply!"
    print("✅ TEST 2 PASSED: Student -> Admin reply delivered successfully.")

    # TEST 3: Admin -> Coach
    res3 = client.post('/api/messages', headers=admin_headers, json={
        'receiver_id': coach_user_id,
        'content': 'Ümmü Hoca, yeni kaynak önerinizi inceledim.'
    })
    assert res3.status_code == 200
    msg3_id = res3.get_json()['id']

    c_msgs = client.get(f'/api/messages/conversations/{admin_user_id}', headers=coach_headers).get_json()['messages']
    found_msg3 = [m for m in c_msgs if m['id'] == msg3_id]
    assert len(found_msg3) > 0, "Coach did not receive Admin's message!"
    print("✅ TEST 3 PASSED: Admin -> Coach message delivered successfully.")

    # TEST 4: Coach -> Admin
    res4 = client.post('/api/messages', headers=coach_headers, json={
        'receiver_id': admin_user_id,
        'content': 'Harika, bu hafta öğrencilerin programını güncelliyorum.'
    })
    assert res4.status_code == 200
    msg4_id = res4.get_json()['id']

    adm_c_msgs = client.get(f'/api/messages/conversations/{coach_user_id}', headers=admin_headers).get_json()['messages']
    found_msg4 = [m for m in adm_c_msgs if m['id'] == msg4_id]
    assert len(found_msg4) > 0, "Admin did not receive Coach's reply!"
    print("✅ TEST 4 PASSED: Coach -> Admin reply delivered successfully.")

    # TEST 5: Unread Increment
    un_before = client.get('/api/messages/unread-count', headers=student2_headers).get_json()['unread_count']
    res5 = client.post('/api/messages', headers=admin_headers, json={
        'receiver_id': student2_user_id,
        'content': 'Merhaba Mert, bu hafta deneme sınavın var.'
    })
    assert res5.status_code == 200
    un_after = client.get('/api/messages/unread-count', headers=student2_headers).get_json()['unread_count']
    assert un_after == un_before + 1, f"Unread counter did not increment cleanly! Before: {un_before}, After: {un_after}"
    print(f"✅ TEST 5 PASSED: Unread counter incremented cleanly (+1, total: {un_after}).")

    # TEST 6: Unread Decrement / Opening Conversation
    res6_open = client.get(f'/api/messages/conversations/{admin_user_id}', headers=student2_headers)
    assert res6_open.status_code == 200
    un_opened = client.get('/api/messages/unread-count', headers=student2_headers).get_json()['unread_count']
    assert un_opened < un_after, f"Unread count did not decrease upon opening conversation! Before: {un_after}, After: {un_opened}"
    print(f"✅ TEST 6 PASSED: Unread counter decreased cleanly upon opening thread (Now: {un_opened}).")

    # TEST 7: Open Conversation Marks All Unread Messages as Read
    c_list = client.get('/api/messages/conversations', headers=student2_headers).get_json()['contacts']
    target_c = next((c for c in c_list if c['user_id'] == admin_user_id), None)
    if target_c:
        assert target_c['unread_count'] == 0, "Conversation unread count was not 0 after opening!"
    print("✅ TEST 7 PASSED: All unread messages in conversation marked as read.")

    # TEST 8: State Persistence
    s1_contacts_again = client.get('/api/messages/conversations', headers=student1_headers).get_json()['contacts']
    assert len(s1_contacts_again) > 0, "Contacts lost upon re-fetching!"
    print("✅ TEST 8 PASSED: Message history and read statuses persisted cleanly.")

    # TEST 9: Search Query Filtering
    search_res = client.get(f'/api/messages/conversations/{admin_user_id}?q=programın', headers=student1_headers).get_json()['messages']
    assert len(search_res) > 0, "Search query returned no results for matching text!"
    print("✅ TEST 9 PASSED: Search query filtering working accurately.")

    # TEST 10: RBAC Security - Coach to Coach Isolation
    # Coach A (ummu.akcan) attempts to fetch Coach B (ahmet.yilmaz) conversation via API
    coach2_login = client.post('/api/login', json={'username': 'ahmet.yilmaz', 'password': 'password123'}).get_json()
    coach2_user_id = coach2_login['user']['id']
    res10 = client.get(f'/api/messages/conversations/{coach2_user_id}', headers=coach_headers)
    assert res10.status_code == 403, f"Coach 1 was able to access Coach 2's conversation! Code: {res10.status_code}"
    print("✅ TEST 10 PASSED: Coach RBAC strictly blocked peer-to-peer coach conversation access (403 Forbidden).")

    # TEST 11: RBAC Security - Student Isolation
    res11 = client.get(f'/api/messages/conversations/{student2_user_id}', headers=student1_headers)
    assert res11.status_code == 403, f"Student 1 was able to access Student 2's conversation! Code: {res11.status_code}"
    print("✅ TEST 11 PASSED: Student RBAC strictly blocked peer-to-peer student conversation access (403 Forbidden).")

    print("=" * 60)
    print("🎉 ALL 11 MESSAGING TEST SCENARIOS PASSED 100%!")
    print("=" * 60)

if __name__ == '__main__':
    run_messaging_test_suite()
