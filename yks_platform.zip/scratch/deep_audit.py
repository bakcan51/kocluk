import re
import sys

APP_PATH = "/Users/burakakcan/.gemini/antigravity/scratch/yks_platform/frontend/app.js"

with open(APP_PATH, "r", encoding="utf-8") as f:
    raw_code = f.read()

lines = raw_code.splitlines()

print(f"Loaded frontend/app.js ({len(lines)} lines)")

# Standard built-ins in browser environment
BUILTINS = {
    'alert', 'confirm', 'prompt', 'console', 'parseInt', 'parseFloat', 'isNaN', 'isFinite',
    'encodeURIComponent', 'decodeURIComponent', 'encodeURI', 'decodeURI',
    'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval', 'requestAnimationFrame',
    'fetch', 'location', 'document', 'window', 'localStorage', 'sessionStorage', 'navigator',
    'Math', 'Date', 'JSON', 'Object', 'Array', 'String', 'Number', 'Boolean', 'RegExp', 'Error',
    'Promise', 'Set', 'Map', 'URL', 'URLSearchParams', 'FormData', 'Blob', 'File', 'FileReader',
    'Event', 'CustomEvent', 'Element', 'HTMLElement', 'Image', 'Audio', 'lucide', 'Chart', 'Swal', 'bootstrap', 'feather', 'L', 'tippy',
    'event', 'this', 'super', 'self', 'arguments', 'null', 'undefined', 'true', 'false', 'NaN', 'Infinity',
    'eval', 'typeof', 'instanceof', 'void', 'delete', 'new', 'return', 'yield', 'await', 'import', 'export',
    'catch', 'finally', 'try', 'throw', 'if', 'else', 'switch', 'case', 'default', 'for', 'while', 'do', 'break', 'continue'
}

# Collect all global/top-level declarations
declared_symbols = set(BUILTINS)
func_decls = []
var_decls = set()

# Pattern for function declarations: function name(...), async function name(...), window.name = ..., const name = ..., let name = ...
for idx, line in enumerate(lines, 1):
    # function declaration
    m_func = re.finditer(r'(?:async\s+)?function\s+([a-zA-Z0-9_$]+)\s*\(', line)
    for m in m_func:
        func_name = m.group(1)
        declared_symbols.add(func_name)
        func_decls.append((idx, func_name, line.strip()))
    
    # window property assignment: window.name = 
    m_win = re.finditer(r'window\.([a-zA-Z0-9_$]+)\s*=', line)
    for m in m_win:
        declared_symbols.add(m.group(1))

    # Top-level var/let/const declaration
    m_var = re.finditer(r'(?:var|let|const)\s+([a-zA-Z0-9_$]+)\s*=', line)
    for m in m_var:
        declared_symbols.add(m.group(1))

# -------------------------------------------------------------
# CHECK 2.e: Duplicate Function Declarations
# -------------------------------------------------------------
print("\n==================================================")
print("CHECK 2.e: Duplicate Function Declarations")
print("==================================================")
func_map = {}
dup_functions = []
for line_num, name, line_str in func_decls:
    if name in func_map:
        dup_functions.append((name, func_map[name], line_num, line_str))
    else:
        func_map[name] = line_num

for name, orig_line, dup_line, line_str in dup_functions:
    print(f"[DUPLICATE FUNCTION] '{name}' original L{orig_line}, duplicate L{dup_line}: {line_str}")

if not dup_functions:
    print("Zero duplicate function declarations found.")


# -------------------------------------------------------------
# CHECK 2.a: Undefined Global Functions in HTML Templates & Event Handlers
# -------------------------------------------------------------
print("\n==================================================")
print("CHECK 2.a: Undefined Event Handler Functions in Templates")
print("==================================================")

# Search for event attributes: on[a-z]+="..." or on[a-z]+='...'
event_matches = []
for idx, line in enumerate(lines, 1):
    # Match inline event handlers like onclick="fnName(...)"
    matches = re.finditer(r'on[a-z]+\s*=\s*["\']\s*(?:javascript:)?([^"\'\n>]+)["\']', line)
    for m in matches:
        expr = m.group(1).strip()
        # extract function calls inside expr
        calls = re.findall(r'([a-zA-Z0-9_$]+)\s*\(', expr)
        for c in calls:
            if c not in declared_symbols and c not in {'preventDefault', 'stopPropagation', 'toggle', 'switch', 'return'}:
                event_matches.append((idx, c, expr, line.strip()))

for line_num, func_name, expr, line_str in event_matches:
    print(f"[UNDEFINED EVENT FUNC] L{line_num}: '{func_name}' in handler `{expr}`")

if not event_matches:
    print("Zero undefined event handler functions found.")


# -------------------------------------------------------------
# CHECK 2.b: Block Scoping (try/catch, if/for)
# -------------------------------------------------------------
print("\n==================================================")
print("CHECK 2.b: Block Scope (const/let in try, used in catch or outside)")
print("==================================================")

# Precise try/catch block parser
try_scope_errors = []
i = 0
n = len(lines)

while i < n:
    line = lines[i]
    if re.search(r'\btry\s*\{', line):
        try_start_line = i + 1
        try_vars = set()
        
        # Scan try block until catch
        brace_count = line.count('{') - line.count('}')
        j = i + 1
        found_catch = False
        catch_start_line = 0
        catch_lines = []
        
        while j < n:
            curr_line = lines[j]
            # Collect const/let declared inside try block
            c_lets = re.findall(r'\b(?:const|let)\s+([a-zA-Z0-9_$]+)\s*=', curr_line)
            for v in c_lets:
                try_vars.add(v)
            
            # Destructuring const { a, b } = ...
            c_dest = re.findall(r'\b(?:const|let)\s+\{([^}]+)\}\s*=', curr_line)
            for d in c_dest:
                for v in re.findall(r'\b[a-zA-Z0-9_$]+\b', d):
                    try_vars.add(v)
            
            if re.search(r'\}\s*catch\b', curr_line):
                found_catch = True
                catch_start_line = j + 1
                j += 1
                break
            
            j += 1
        
        if found_catch:
            # Collect lines inside catch block
            catch_brace_count = 1
            while j < n:
                c_line = lines[j]
                catch_brace_count += c_line.count('{') - c_line.count('}')
                catch_lines.append((j + 1, c_line))
                if catch_brace_count <= 0 or re.search(r'^\s*\}', c_line):
                    break
                j += 1
            
            # Check catch_lines for references to try_vars
            for l_num, c_line in catch_lines:
                # Strip strings and single-line comments
                clean_l = re.sub(r'//.*', '', c_line)
                clean_l = re.sub(r'\'[^\']*\'|"[^"]*"|`[^`]*`', '', clean_l)
                
                # Extract word tokens
                tokens = re.findall(r'\b[a-zA-Z0-9_$]+\b', clean_l)
                for tv in try_vars:
                    if tv in tokens:
                        # Ensure it's not a parameter name or re-declaration
                        if not re.search(r'\b(?:const|let|var|catch\s*\()\s*' + re.escape(tv) + r'\b', clean_l):
                            # Ensure it's not property access like obj.tv
                            if not re.search(r'\.\s*' + re.escape(tv) + r'\b', clean_l):
                                try_scope_errors.append((try_start_line, catch_start_line, l_num, tv, c_line.strip()))
        i = j
    else:
        i += 1

for try_line, catch_line, ref_line, var_name, line_str in try_scope_errors:
    print(f"[TRY/CATCH SCOPE ERROR] try(L{try_line}) declared const/let '{var_name}', referenced in catch(L{catch_line}) on L{ref_line}: {line_str}")

if not try_scope_errors:
    print("Zero try/catch block scope errors found.")


# -------------------------------------------------------------
# CHECK 2.d: Missing Await on Async Function Calls
# -------------------------------------------------------------
print("\n==================================================")
print("CHECK 2.d: Missing Await on Async Function Calls")
print("==================================================")

async_functions = set()
# Find all declared async functions
for idx, line in enumerate(lines, 1):
    m = re.finditer(r'async\s+function\s+([a-zA-Z0-9_$]+)\s*\(', line)
    for match in m:
        async_functions.add(match.group(1))
    m2 = re.finditer(r'(?:const|let|var)\s+([a-zA-Z0-9_$]+)\s*=\s*async\s*\(', line)
    for match in m2:
        async_functions.add(match.group(1))

print(f"Total async functions identified: {len(async_functions)}")

missing_awaits = []
for idx, line in enumerate(lines, 1):
    # Strip comments and strings
    clean = re.sub(r'//.*', '', line)
    clean = re.sub(r'\'[^\']*\'|"[^"]*"', '', clean)
    
    # Look for calls to async functions
    for af in async_functions:
        # Match af(...) not preceded by await
        # e.g. const res = af(...) or af(...) directly
        pattern = r'(?<!await\s)(?<!function\s)(?<!async\s)\b' + re.escape(af) + r'\s*\('
        if re.search(pattern, clean):
            # Exclude function declarations itself (async function af(...) or function af(...))
            if not re.search(r'\bfunction\s+' + re.escape(af), clean) and not re.search(r'on[a-z]+\s*=', line):
                missing_awaits.append((idx, af, line.strip()))

for line_num, func_name, line_str in missing_awaits:
    print(f"[MISSING AWAIT] L{line_num}: call to async function '{func_name}' without await: {line_str}")

if not missing_awaits:
    print("Zero missing await calls found.")


# -------------------------------------------------------------
# CHECK 2.c: Typos in Variable Names
# -------------------------------------------------------------
print("\n==================================================")
print("CHECK 2.c: Variable Typos & Unresolved Identifier Scan")
print("==================================================")

# Collect all identifier usages per function block and look for single-use identifiers or common typos
# e.g. studentt, stduent, responsee, resposne, elemnt, elment, etc.
common_typo_patterns = [
    (r'\bstudentt\b', 'student'),
    (r'\bstduent\b', 'student'),
    (r'\bstudnet\b', 'student'),
    (r'\bresposne\b', 'response'),
    (r'\bresponsee\b', 'response'),
    (r'\belemnt\b', 'element'),
    (r'\belment\b', 'element'),
    (r'\bdatta\b', 'data'),
    (r'\bdta\b', 'data'),
    (r'\bkonuIdd\b', 'konuId'),
    (r'\bkaynakIdd\b', 'kaynakId'),
    (r'\bdenemeIdd\b', 'denemeId'),
]

typos_found = []
for idx, line in enumerate(lines, 1):
    clean = re.sub(r'//.*', '', line)
    clean = re.sub(r'\'[^\']*\'|"[^"]*"', '', clean)
    for pattern, correct in common_typo_patterns:
        if re.search(pattern, clean, re.IGNORECASE):
            typos_found.append((idx, pattern, correct, line.strip()))

for line_num, pattern, correct, line_str in typos_found:
    print(f"[TYPO FOUND] L{line_num}: Pattern {pattern} (suggested: {correct}): {line_str}")

if not typos_found:
    print("No common typo patterns found.")

