import urllib.request
import json
import sys

BASE_URL = "http://127.0.0.1:5005/api"

def make_request(url, method="GET", data=None, headers=None):
    if headers is None:
        headers = {}
    if data is not None:
        data_bytes = json.dumps(data).encode('utf-8')
        headers["Content-Type"] = "application/json"
    else:
        data_bytes = None

    req = urllib.request.Request(url, data=data_bytes, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req) as resp:
            body = resp.read().decode('utf-8')
            return resp.status, json.loads(body) if body else {}
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8')
        return e.code, json.loads(body) if body else {"error": str(e)}

def test_admin_resource_management_suite():
    print("==================================================")
    print("🚀 TESTING ADMIN RESOURCE MANAGEMENT SUITE (6 SUB-TABS)")
    print("==================================================")

    # 1. Login as Admin
    status, res = make_request(f"{BASE_URL}/login", method="POST", data={"username": "admin", "password": "admin123"})
    assert status == 200, f"Admin login failed: {status} - {res}"
    admin_token = res["token"]
    admin_headers = {"Authorization": f"Bearer {admin_token}"}
    print("✅ 1. Admin login successful.")

    # 2. Test GET /api/admin/resource-management/stats (Scorecards)
    status, stats_data = make_request(f"{BASE_URL}/admin/resource-management/stats", headers=admin_headers)
    assert status == 200, f"Stats error: {stats_data}"
    print(f"✅ 2. KPI Stats retrieved: {stats_data}")
    assert "total_general_resources" in stats_data
    assert "pending_suggestions_count" in stats_data
    assert "total_publishers" in stats_data
    assert "total_subjects" in stats_data

    # 3. Test Tab 1: GET /api/kaynak-havuzu (General System Pool)
    status, gen_json = make_request(f"{BASE_URL}/kaynak-havuzu?tab=SYSTEM", headers=admin_headers)
    assert status == 200, f"Genel pool error: {gen_json}"
    gen_resources = gen_json.get("resources", [])
    print(f"✅ 3. Genel Kaynak Havuzu retrieved: {len(gen_resources)} resources found.")

    if len(gen_resources) > 0:
        res_id = gen_resources[0]["id"]
        # Test Detail Modal Endpoint
        status, det_json = make_request(f"{BASE_URL}/kaynak-havuzu/{res_id}/details", headers=admin_headers)
        assert status == 200, f"Resource detail error: {det_json}"
        assert "resource" in det_json
        assert "statistics" in det_json
        print(f"✅ 4. Resource Details endpoint verified for ID #{res_id}: {det_json['resource']['name']}")

    # 4. Test Tab 2: GET /api/admin/resource-suggestions
    status, sug_json = make_request(f"{BASE_URL}/admin/resource-suggestions", headers=admin_headers)
    assert status == 200, f"Suggestions error: {sug_json}"
    suggestions = sug_json.get("suggestions", [])
    print(f"✅ 5. Resource Suggestions retrieved: {len(suggestions)} suggestions found.")

    # 5. Test Coach Login and creating a new suggestion
    status_c, res_c = make_request(f"{BASE_URL}/login", method="POST", data={"username": "koc1", "password": "Password123!"})
    if status_c == 200:
        c_token = res_c["token"]
        c_headers = {"Authorization": f"Bearer {c_token}"}
        
        # Add new resource as Coach (generates suggestion)
        status_add, res_add = make_request(f"{BASE_URL}/kaynak-havuzu", method="POST", headers=c_headers, data={
            "name": "2026 Özel Geometri Soru Bankası Test",
            "publisher": "Test Yayınevi",
            "subject_id": 3,
            "exam_system": "YKS",
            "exam_type": "TYT",
            "field": "ALL",
            "resource_type": "Soru Bankası",
            "level": "Zor",
            "description": "Otomatik test kaynak önerisi"
        })
        assert status_add == 200, f"Coach resource addition failed: {res_add}"
        print("✅ 6. Coach successfully added private resource & suggestion generated.")

        # Re-fetch suggestions as Admin
        status, sug_json2 = make_request(f"{BASE_URL}/admin/resource-suggestions", headers=admin_headers)
        suggestions2 = sug_json2.get("suggestions", [])
        pending_sug = [s for s in suggestions2 if s["status"] == "BEKLİYOR"]
        print(f"   Pending suggestions count: {len(pending_sug)}")
        assert len(pending_sug) > 0

        # Test Rejection with reason
        sug_id = pending_sug[0]["id"]
        status_rej, res_rej = make_request(f"{BASE_URL}/admin/resource-suggestions/{sug_id}/respond", method="POST", headers=admin_headers, data={
            "action": "REJECT",
            "rejection_reason": "Zaten genel havuzda benzeri var."
        })
        assert status_rej == 200, f"Rejection failed: {res_rej}"
        print(f"✅ 7. Suggestion ID #{sug_id} REJECTED with reason verified.")

    # 6. Test Tab 3: GET /api/admin/coach-resources
    status, coaches_json = make_request(f"{BASE_URL}/admin/coach-resources", headers=admin_headers)
    assert status == 200
    coaches_list = coaches_json.get("coaches", [])
    print(f"✅ 8. Coach Pools overview retrieved: {len(coaches_list)} coaches listed.")

    if len(coaches_list) > 0:
        c_id = coaches_list[0]["id"]
        status, pool_json = make_request(f"{BASE_URL}/admin/coach-resources?coach_id={c_id}", headers=admin_headers)
        assert status == 200
        print(f"   Coach ID #{c_id} pool: {pool_json['summary']['total_resources']} resources ({pool_json['summary']['coach_added_count']} coach custom).")

        # Test promoting coach resource to system
        coach_res_list = [r for r in pool_json.get("resources", []) if r.get("source_type") == "Koç Kaynağı"]
        if len(coach_res_list) > 0:
            status_p, res_p = make_request(f"{BASE_URL}/admin/coach-resources/{coach_res_list[0]['id']}/promote-to-system", method="POST", headers=admin_headers)
            assert status_p == 200
            print(f"✅ 9. Coach resource ID #{coach_res_list[0]['id']} promoted to Genel Havuz successfully.")

    # 7. Test Tab 4: Publishers API (GET, POST, PUT)
    status, pub_json = make_request(f"{BASE_URL}/admin/publishers", headers=admin_headers)
    assert status == 200
    publishers = pub_json.get("publishers", [])
    print(f"✅ 10. Publishers retrieved: {len(publishers)} publishers found.")

    status, add_pub = make_request(f"{BASE_URL}/admin/publishers", method="POST", headers=admin_headers, data={"name": "Test Alfa Yayınları"})
    assert status == 200
    new_pub_id = add_pub["publisher_id"]
    print(f"✅ 11. New publisher created with ID #{new_pub_id}.")

    status, pub_upd = make_request(f"{BASE_URL}/admin/publishers/{new_pub_id}", method="PUT", headers=admin_headers, data={"status": "INACTIVE"})
    assert status == 200
    print("✅ 12. Publisher status toggled to INACTIVE.")

    # 8. Test Tab 5: Subjects Summary API
    status, subj_json = make_request(f"{BASE_URL}/admin/subjects-summary", headers=admin_headers)
    assert status == 200
    subjects = subj_json.get("subjects", [])
    print(f"✅ 13. Subjects summary retrieved: {len(subjects)} subjects listed.")

    # 9. Test Tab 6: Resource Analytics API
    status, analytics = make_request(f"{BASE_URL}/admin/resource-analytics", headers=admin_headers)
    assert status == 200
    assert "top_assigned_resources" in analytics
    assert "top_publishers" in analytics
    assert "subject_usage" in analytics
    print(f"✅ 14. Resource Analytics retrieved: {len(analytics['top_assigned_resources'])} top resources.")

    # 10. Test Bulk Action (ACTIVATE / DEACTIVATE)
    if len(gen_resources) >= 2:
        ids_to_bulk = [gen_resources[0]["id"], gen_resources[1]["id"]]
        status, r_bulk = make_request(f"{BASE_URL}/kaynak-havuzu/bulk-action", method="POST", headers=admin_headers, data={
            "resource_ids": ids_to_bulk,
            "action": "DEACTIVATE"
        })
        assert status == 200, f"Bulk deactivate error: {r_bulk}"
        print(f"✅ 15. Bulk deactivate executed on IDs {ids_to_bulk}: {r_bulk.get('message')}")

        status, r_bulk2 = make_request(f"{BASE_URL}/kaynak-havuzu/bulk-action", method="POST", headers=admin_headers, data={
            "resource_ids": ids_to_bulk,
            "action": "ACTIVATE"
        })
        assert status == 200
        print(f"✅ 16. Bulk activate executed on IDs {ids_to_bulk}: {r_bulk2.get('message')}")

    print("==================================================")
    print("🎉 ALL 16 ADMIN RESOURCE MANAGEMENT SUITE TESTS PASSED!")
    print("==================================================")

if __name__ == "__main__":
    test_admin_resource_management_suite()
