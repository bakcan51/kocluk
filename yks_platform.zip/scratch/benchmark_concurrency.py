import sys
import os
import time
import statistics
import concurrent.futures
from datetime import datetime

sys.path.insert(0, os.path.abspath('backend'))
from app import app, get_db

def verify_threaded_config():
    app_py_path = os.path.abspath('backend/app.py')
    with open(app_py_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    is_threaded = "threaded=True" in content
    return is_threaded

def run_benchmarks():
    print("=" * 70)
    print("YKS PLATFORM PERFORMANCE & CONCURRENCY BENCHMARK SUITE")
    print("=" * 70)
    
    # 1. Verify app.run(..., threaded=True)
    threaded_ok = verify_threaded_config()
    print(f"[STEP 1] app.run(..., threaded=True) verification: {'PASSED' if threaded_ok else 'FAILED'}")
    
    # Setup test clients & tokens
    client = app.test_client()
    
    # Login Coach
    res_c = client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
    coach_token = res_c.get_json().get('token') if res_c.status_code == 200 else None
    
    # Login Student
    res_s = client.post('/api/auth/login', json={'username': 'burak.akcan', 'password': 'ogrenci123'})
    student_token = res_s.get_json().get('token') if res_s.status_code == 200 else None

    if not coach_token or not student_token:
        print("ERROR: Authentication failed during setup!")
        return

    coach_headers = {'Authorization': f'Bearer {coach_token}'}
    student_headers = {'Authorization': f'Bearer {student_token}'}

    # Worker helper function
    def make_request(method, url, headers=None, json_data=None):
        t0 = time.perf_counter()
        tc = app.test_client()
        err_msg = None
        status = 500
        try:
            if method.upper() == 'GET':
                resp = tc.get(url, headers=headers)
            elif method.upper() == 'POST':
                resp = tc.post(url, headers=headers, json=json_data)
            elif method.upper() == 'PUT':
                resp = tc.put(url, headers=headers, json=json_data)
            status = resp.status_code
            if status >= 400:
                err_msg = f"HTTP {status}"
        except Exception as e:
            err_msg = str(e)
            status = 500
        t1 = time.perf_counter()
        elapsed_ms = (t1 - t0) * 1000.0
        return {
            'url': url,
            'status': status,
            'elapsed_ms': elapsed_ms,
            'error': err_msg,
            'is_lock_error': err_msg is not None and ('locked' in err_msg.lower() or status == 500)
        }

    def summarize_results(name, results):
        durations = [r['elapsed_ms'] for r in results]
        statuses = [r['status'] for r in results]
        errors = [r for r in results if r['error'] is not None]
        slow_reqs = [r for r in results if r['elapsed_ms'] > 1000.0]
        lock_errors = [r for r in results if r['is_lock_error']]
        
        avg_ms = statistics.mean(durations) if durations else 0
        min_ms = min(durations) if durations else 0
        max_ms = max(durations) if durations else 0
        
        # 95th percentile
        durations_sorted = sorted(durations)
        p95_idx = int(0.95 * len(durations_sorted)) - 1
        p95_idx = max(0, min(p95_idx, len(durations_sorted) - 1))
        p95_ms = durations_sorted[p95_idx] if durations_sorted else 0
        
        error_rate = (len(errors) / len(results)) * 100.0 if results else 0.0

        print(f"\n--- Benchmark: {name} ---")
        print(f"Total Requests        : {len(results)}")
        print(f"Successful (2xx/3xx)  : {len([s for s in statuses if s < 400])}")
        print(f"Error Reqs (4xx/5xx)  : {len(errors)}")
        print(f"Error Rate (%)        : {error_rate:.2f}%")
        print(f"Min Latency (ms)      : {min_ms:.2f} ms")
        print(f"Avg Latency (ms)      : {avg_ms:.2f} ms")
        print(f"P95 Latency (ms)      : {p95_ms:.2f} ms")
        print(f"Max Latency (ms)      : {max_ms:.2f} ms")
        print(f"Requests > 1.0s       : {len(slow_reqs)} ({(len(slow_reqs)/len(results)*100.0):.1f}%)")
        print(f"SQLite Lock Errors    : {len(lock_errors)}")
        if errors:
            print("Sample Errors         :", [f"{e['url']} -> {e['status']} ({e['error']})" for e in errors[:5]])
        
        return {
            'name': name,
            'total': len(results),
            'success': len([s for s in statuses if s < 400]),
            'errors': len(errors),
            'error_rate': error_rate,
            'min_ms': min_ms,
            'avg_ms': avg_ms,
            'p95_ms': p95_ms,
            'max_ms': max_ms,
            'slow_count': len(slow_reqs),
            'lock_errors': len(lock_errors)
        }

    # ==========================================
    # SCENARIO A: 10 Concurrent Requests across Core Endpoints
    # ==========================================
    endpoints = [
        ('/api/weekly-program?student_id=1&week_start=2026-08-17', coach_headers),
        ('/api/students', coach_headers),
        ('/api/notifications', coach_headers),
        ('/api/kaynaklar', coach_headers),
    ]
    
    tasks_a = []
    # 10 workers submitting 100 total requests (25 cycles across the 4 endpoints)
    for i in range(25):
        for ep_url, ep_hdr in endpoints:
            tasks_a.append(('GET', ep_url, ep_hdr, None))

    print(f"\n[SCENARIO A] Running 10 Concurrent Threads across 4 Core Endpoints ({len(tasks_a)} total requests)...")
    results_a = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(make_request, m, u, h, d) for m, u, h, d in tasks_a]
        for f in concurrent.futures.as_completed(futures):
            results_a.append(f.result())

    metrics_a = summarize_results("10 Concurrent Core API Requests", results_a)

    # ==========================================
    # SCENARIO B: Concurrent Read & Write (GET / PUT / POST) on Same Student Record
    # ==========================================
    print("\n[SCENARIO B] Running Concurrent Read (GET) & Write (POST/PUT) SQLite Lock Test...")
    
    tasks_b = []
    for i in range(20):
        # Read tasks
        tasks_b.append(('GET', '/api/students/1', coach_headers, None))
        tasks_b.append(('GET', '/api/weekly-program?student_id=1&week_start=2026-08-17', coach_headers, None))
        # Write tasks with unique non-overlapping times to avoid business logic 409 conflicts
        hour = 8 + (i // 4)
        min_start = (i % 4) * 15
        min_end = min_start + 10
        tasks_b.append(('POST', '/api/weekly-program', coach_headers, {
            'student_id': 1,
            'date': '2026-08-21',
            'start_time': f'{hour:02d}:{min_start:02d}',
            'end_time': f'{hour:02d}:{min_end:02d}',
            'title': f'Concurrency Test Task {i}',
            'study_type': 'Soru Çözümü'
        }))
        tasks_b.append(('PUT', '/api/students/1/account', coach_headers, {
            'name': 'Burak',
            'surname': 'Akcan',
            'exam_system': 'YKS',
            'track': 'SAYISAL',
            'grade': '12. Sınıf',
            'target_university': 'İTÜ',
            'target_department': 'Bilgisayar Mühendisliği'
        }))

    results_b = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(make_request, m, u, h, d) for m, u, h, d in tasks_b]
        for f in concurrent.futures.as_completed(futures):
            results_b.append(f.result())

    metrics_b = summarize_results("Concurrent Read/Write SQLite Lock Stress", results_b)

    # ==========================================
    # SCENARIO C: High Frequency Notification Polling + Heavy Academic Reports
    # ==========================================
    print("\n[SCENARIO C] High Frequency Notification Polling + Heavy Academic Reports Combined Load...")
    
    poll_tasks = [('GET', '/api/notifications?unread_only=true', student_headers, None) for _ in range(50)]
    report_tasks = [
        ('GET', '/api/raporlar?student_id=1&preset=3_MONTHS', coach_headers, None),
        ('GET', '/api/koc/dashboard', coach_headers, None),
        ('GET', '/api/deneme/analiz?student_id=1', coach_headers, None),
        ('GET', '/api/raporlar?student_id=1&preset=THIS_YEAR', coach_headers, None),
    ] * 5 # 20 heavy report calls

    all_tasks_c = poll_tasks + report_tasks
    
    results_c = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as executor:
        futures = [executor.submit(make_request, m, u, h, d) for m, u, h, d in all_tasks_c]
        for f in concurrent.futures.as_completed(futures):
            results_c.append(f.result())

    metrics_c = summarize_results("High Freq Polling + Heavy Reports", results_c)
    
    # Also separate metrics for light polling vs heavy reports in Scenario C
    poll_results = [r for r in results_c if '/api/notifications' in r['url']]
    report_results = [r for r in results_c if '/api/notifications' not in r['url']]
    
    metrics_c_poll = summarize_results("Scenario C - Notification Polling Only", poll_results)
    metrics_c_reports = summarize_results("Scenario C - Heavy Academic Reports Only", report_results)

    print("\n" + "=" * 70)
    print("BENCHMARK COMPLETED SUCCESSFULLY!")
    print("=" * 70)

if __name__ == '__main__':
    run_benchmarks()
