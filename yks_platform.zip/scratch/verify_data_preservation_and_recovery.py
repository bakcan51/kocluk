import sys
import os
import unittest

sys.path.insert(0, os.path.abspath('backend'))
from app import app

class DataPreservationAndRecoveryTest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
        res = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        self.assertEqual(res.status_code, 200)
        self.token = res.get_json()['token']

    def test_01_verify_students_preserved_and_ordered(self):
        res = self.client.get('/api/students', headers={'Authorization': f'Bearer {self.token}'})
        self.assertEqual(res.status_code, 200)
        students = res.get_json()['students']
        self.assertGreaterEqual(len(students), 13)
        # Verify student 1 (Burak Akcan) is first in list by ID
        self.assertEqual(students[0]['id'], 1)

    def test_02_verify_mock_exams_data(self):
        res = self.client.get('/api/deneme?student_id=1', headers={'Authorization': f'Bearer {self.token}'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['summary']['total_exams'], 19)
        self.assertEqual(len(data['attempts']), 19)

    def test_03_verify_assignments_and_weekly_programs(self):
        res_a = self.client.get('/api/odevler?student_id=1', headers={'Authorization': f'Bearer {self.token}'})
        self.assertEqual(res_a.status_code, 200)
        assignments = res_a.get_json().get('assignments', [])
        self.assertGreater(len(assignments), 0)

        res_p = self.client.get('/api/weekly-program?student_id=1&week_start=2026-08-10', headers={'Authorization': f'Bearer {self.token}'})
        self.assertEqual(res_p.status_code, 200)

if __name__ == '__main__':
    unittest.main()
