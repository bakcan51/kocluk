import sys
import os
import json

sys.path.insert(0, os.path.abspath('backend'))

from backend.app import app

def run_suite():
    print("==================================================")
    print("🚀 RUNNING ADMIN RESOURCE MANAGEMENT SUITE (6 SUB-TABS)")
    print("==================================================")

    client = app.test_client()

    # 1. Login as Admin
    res = client.post('/api/login', json={'username': 'admin', 'password': 'admin123'})
    assert res.status_code == 200, f"Admin login failed: {res.status_code} - {res.get_data(as_text=True)}"
    admin_token = res.get_json()['token']
    admin_headers = {'Authorization': f'Bearer {admin_token}'}
    print("✅ 1. Admin login successful.")

    # 2. Test GET /api/admin/resource-management/stats (5 Scorecards)
    res = client.get('/api/admin/resource-management/stats', headers=admin_headers)
    assert res.status_code == 200, f"Stats error: {res.get_data(as_text=True)}"
    stats = res.get_json()
    print(f"✅ 2. KPI Stats retrieved: {stats}")
    assert 'total_general_resources' in stats
    assert 'pending_suggestions_count' in stats
    assert 'total_publishers' in stats
    assert 'total_subjects' in stats

    # 3. Test Tab 1: GET /api/kaynak-havuzu (General System Pool)
    res = client.get('/api/kaynak-havuzu?tab=SYSTEM', headers=admin_headers)
    assert res.status_code == 200, f"Genel pool error: {res.get_data(as_text=True)}"
    gen_resources = res.get_json().get('resources', [])
    print(f"✅ 3. Genel Kaynak Havuzu retrieved: {len(gen_resources)} resources found.")

    if len(gen_resources) > 0:
        res_id = gen_resources[0]['id']
        # Test Detail Modal Endpoint
        res = client.get(f'/api/kaynak-havuzu/{res_id}/details', headers=admin_headers)
        assert res.status_code == 200, f"Resource detail error: {res.get_data(as_text=True)}"
        det_json = res.get_json()
        assert 'resource' in det_json
        assert 'statistics' in det_json
        print(f"✅ 4. Resource Details endpoint verified for ID #{res_id}: {det_json['resource']['name']}")

    # 4. Test Tab 2: GET /api/admin/resource-suggestions
    res = client.get('/api/admin/resource-suggestions', headers=admin_headers)
    assert res.status_code == 200, f"Suggestions error: {res.get_data(as_text=True)}"
    suggestions = res.get_json().get('suggestions', [])
    print(f"✅ 5. Resource Suggestions retrieved: {len(suggestions)} suggestions found.")

    # 5. Test Coach Login and creating a new suggestion
    res = client.post('/api/login', json={'username': 'ummu.akcan', 'password': 'Password123!'})
    if res.status_code == 200:
        c_token = res.get_json()['token']
        c_headers = {'Authorization': f'Bearer {c_token}'}
        
        # Add new resource as Coach (generates suggestion)
        res = client.post('/api/kaynak-havuzu', headers=c_headers, json={
            'name': '2026 Özel Geometri Soru Bankası Suite Test',
            'publisher': 'Test Yayınevi Suite',
            'subject_id': 3,
            'exam_system': 'YKS',
            'exam_type': 'TYT',
            'field': 'ALL',
            'resource_type': 'Soru Bankası',
            'level': 'Zor',
            'description': 'Otomatik test kaynak önerisi'
        })
        assert res.status_code == 200, f"Coach resource addition failed: {res.get_data(as_text=True)}"
        print("✅ 6. Coach successfully added private resource & suggestion generated.")

        # Re-fetch suggestions as Admin
        res = client.get('/api/admin/resource-suggestions', headers=admin_headers)
        suggestions2 = res.get_json().get('suggestions', [])
        pending_sug = [s for s in suggestions2 if s['status'] == 'BEKLİYOR']
        print(f"   Pending suggestions count: {len(pending_sug)}")
        assert len(pending_sug) > 0

        # Test Rejection with reason
        sug_id = pending_sug[0]['id']
        res = client.post(f'/api/admin/resource-suggestions/{sug_id}/respond', headers=admin_headers, json={
            'action': 'REJECT',
            'rejection_reason': 'Zaten genel havuzda benzeri var.'
        })
        assert res.status_code == 200, f"Rejection failed: {res.get_data(as_text=True)}"
        print(f"✅ 7. Suggestion ID #{sug_id} REJECTED with reason verified.")

    # 6. Test Tab 3: GET /api/admin/coach-resources
    res = client.get('/api/admin/coach-resources', headers=admin_headers)
    assert res.status_code == 200
    coaches_list = res.get_json().get('coaches', [])
    print(f"✅ 8. Coach Pools overview retrieved: {len(coaches_list)} coaches listed.")

    if len(coaches_list) > 0:
        c_id = coaches_list[0]['id']
        res = client.get(f'/api/admin/coach-resources?coach_id={c_id}', headers=admin_headers)
        assert res.status_code == 200
        pool_json = res.get_json()
        print(f"   Coach ID #{c_id} pool: {pool_json['summary']['total_resources']} resources ({pool_json['summary']['coach_added_count']} coach custom).")

        # Test promoting coach resource to system
        coach_res_list = [r for r in pool_json.get('resources', []) if r.get('source_type') == 'Koç Kaynağı']
        if len(coach_res_list) > 0:
            res = client.post(f"/api/admin/coach-resources/{coach_res_list[0]['id']}/promote-to-system", headers=admin_headers)
            assert res.status_code == 200
            print(f"✅ 9. Coach resource ID #{coach_res_list[0]['id']} promoted to Genel Havuz successfully.")

    # 7. Test Tab 4: Publishers API (GET, POST, PUT)
    res = client.get('/api/admin/publishers', headers=admin_headers)
    assert res.status_code == 200
    publishers = res.get_json().get('publishers', [])
    print(f"✅ 10. Publishers retrieved: {len(publishers)} publishers found.")

    res = client.post('/api/admin/publishers', headers=admin_headers, json={'name': 'Test Alfa Yayınları'})
    assert res.status_code == 200
    new_pub_id = res.get_json()['publisher_id']
    print(f"✅ 11. New publisher created with ID #{new_pub_id}.")

    res = client.put(f'/api/admin/publishers/{new_pub_id}', headers=admin_headers, json={'status': 'INACTIVE'})
    assert res.status_code == 200
    print("✅ 12. Publisher status toggled to INACTIVE.")

    # 8. Test Tab 5: Subjects Summary API
    res = client.get('/api/admin/subjects-summary', headers=admin_headers)
    assert res.status_code == 200
    subjects = res.get_json().get('subjects', [])
    print(f"✅ 13. Subjects summary retrieved: {len(subjects)} subjects listed.")

    # 9. Test Tab 6: Resource Analytics API
    res = client.get('/api/admin/resource-analytics', headers=admin_headers)
    assert res.status_code == 200
    analytics = res.get_json()
    assert 'top_assigned_resources' in analytics
    assert 'top_publishers' in analytics
    assert 'subject_usage' in analytics
    print(f"✅ 14. Resource Analytics retrieved: {len(analytics['top_assigned_resources'])} top resources.")

    # 10. Test Bulk Action (ACTIVATE / DEACTIVATE)
    if len(gen_resources) >= 2:
        ids_to_bulk = [gen_resources[0]['id'], gen_resources[1]['id']]
        res = client.post('/api/kaynak-havuzu/bulk-action', headers=admin_headers, json={
            'resource_ids': ids_to_bulk,
            'action': 'DEACTIVATE'
        })
        assert res.status_code == 200, f"Bulk deactivate error: {res.get_data(as_text=True)}"
        print(f"✅ 15. Bulk deactivate executed on IDs {ids_to_bulk}: {res.get_json().get('message')}")

        res = client.post('/api/kaynak-havuzu/bulk-action', headers=admin_headers, json={
            'resource_ids': ids_to_bulk,
            'action': 'ACTIVATE'
        })
        assert res.status_code == 200
        print(f"✅ 16. Bulk activate executed on IDs {ids_to_bulk}: {res.get_json().get('message')}")

    print("==================================================")
    print("🎉 ALL 16 ADMIN RESOURCE MANAGEMENT SUITE TESTS PASSED!")
    print("==================================================")

if __name__ == "__main__":
    run_suite()
