import sys
import os
import unittest

sys.path.insert(0, os.path.abspath('backend'))
from app import app

class WeeklyProgramFullRecoveryTest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

        # Coach Login
        res_c = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        self.assertEqual(res_c.status_code, 200)
        self.coach_token = res_c.get_json()['token']

        # Student Login (Mert Demir - Student ID 3 in DB, User ID 6)
        res_s = self.client.post('/api/auth/login', json={'username': 'mert.demir', 'password': 'ogrenci123'})
        self.assertEqual(res_s.status_code, 200)
        self.student_token = res_s.get_json()['token']

    def test_01_create_task_and_verify_persistence(self):
        # Clear week start 2026-08-17 for Student 3 (Mert)
        self.client.post('/api/weekly-program/clear', json={'student_id': 3, 'week_start': '2026-08-17'}, headers={'Authorization': f'Bearer {self.coach_token}'})

        # Coach creates task for Student 3
        payload = {
            'student_id': 3,
            'date': '2026-08-17',
            'day_of_week': 'Pazartesi',
            'start_time': '09:00',
            'end_time': '10:00',
            'title': 'Matematik Problemler 40 Soru',
            'status': 'PLANLANDI',
            'publication_status': 'PUBLISHED'
        }
        res = self.client.post('/api/weekly-program', json=payload, headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 200)
        prog_id = res.get_json()['id']

        # Student 3 fetches program
        res_st = self.client.get('/api/weekly-program?week_start=2026-08-17', headers={'Authorization': f'Bearer {self.student_token}'})
        self.assertEqual(res_st.status_code, 200)
        items = res_st.get_json()['items']
        target = next((i for i in items if i['id'] == prog_id), None)
        self.assertIsNotNone(target)
        self.assertEqual(target['title'], 'Matematik Problemler 40 Soru')

        # Student marks completed
        res_comp = self.client.post(f'/api/weekly-program/{prog_id}/status', json={'status': 'TAMAMLANDI'}, headers={'Authorization': f'Bearer {self.student_token}'})
        self.assertEqual(res_comp.status_code, 200)

        # Coach verifies status is TAMAMLANDI
        res_c = self.client.get('/api/weekly-program?student_id=3&week_start=2026-08-17', headers={'Authorization': f'Bearer {self.coach_token}'})
        items_c = res_c.get_json()['items']
        target_c = next((i for i in items_c if i['id'] == prog_id), None)
        self.assertEqual(target_c['status'], 'TAMAMLANDI')

    def test_02_student_isolation(self):
        # Coach fetches Student 2 (Elif Yılmaz) program for same week
        res_e = self.client.get('/api/weekly-program?student_id=2&week_start=2026-08-17', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res_e.status_code, 200)
        items_e = res_e.get_json()['items']
        # Elif should not have Student 3's task items
        for i in items_e:
            self.assertEqual(i['student_id'], 2)

if __name__ == '__main__':
    unittest.main()
