import sys
import os
import unittest

sys.path.insert(0, os.path.abspath('backend'))
from app import app

class WeeklyProgramSimplifiedTest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

        # Coach Login
        res_c = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        self.assertEqual(res_c.status_code, 200)
        self.coach_token = res_c.get_json()['token']

        # Student Login (Mert Demir - Student ID 3 in DB, User ID 6)
        res_s = self.client.post('/api/auth/login', json={'username': 'mert.demir', 'password': 'ogrenci123'})
        self.assertEqual(res_s.status_code, 200)
        self.student_token = res_s.get_json()['token']

        # Clear week first
        self.client.post('/api/weekly-program/clear', json={'student_id': 3, 'week_start': '2026-08-17'}, headers={'Authorization': f'Bearer {self.coach_token}'})

    def test_01_coach_creates_and_updates_free_text_cell(self):
        # Create a task for Student 3 (Mert Demir) on 2026-08-17 09:00
        payload = {
            'student_id': 3,
            'date': '2026-08-17',
            'day_of_week': 'Pazartesi',
            'start_time': '09:00',
            'end_time': '10:00',
            'title': 'Matematik Problemler 40 Soru',
            'status': 'PLANLANDI',
            'publication_status': 'PUBLISHED'
        }
        res = self.client.post('/api/weekly-program', json=payload, headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 200)
        prog_id = res.get_json()['id']

        # Verify task is returned for Student 3
        res_g = self.client.get('/api/weekly-program?student_id=3&week_start=2026-08-17', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res_g.status_code, 200)
        items = res_g.get_json()['items']
        target_item = next((i for i in items if i['id'] == prog_id), None)
        self.assertIsNotNone(target_item)
        self.assertEqual(target_item['title'], 'Matematik Problemler 40 Soru')

        # Update task free text
        res_u = self.client.put(f'/api/weekly-program/{prog_id}', json={'title': 'Matematik 60 Soru'}, headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res_u.status_code, 200)

        # Verify updated title
        res_g2 = self.client.get('/api/weekly-program?student_id=3&week_start=2026-08-17', headers={'Authorization': f'Bearer {self.coach_token}'})
        items2 = res_g2.get_json()['items']
        target_item2 = next((i for i in items2 if i['id'] == prog_id), None)
        self.assertEqual(target_item2['title'], 'Matematik 60 Soru')

    def test_02_student_toggles_completion_and_coach_sees_status(self):
        # Create a task as Coach
        payload = {
            'student_id': 3,
            'date': '2026-08-17',
            'day_of_week': 'Pazartesi',
            'start_time': '10:00',
            'end_time': '11:00',
            'title': 'Türkçe Paragraf 30 Soru',
            'status': 'PLANLANDI',
            'publication_status': 'PUBLISHED'
        }
        res_c_create = self.client.post('/api/weekly-program', json=payload, headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res_c_create.status_code, 200)
        prog_id = res_c_create.get_json()['id']

        # Fetch items as Student (Mert)
        res_s = self.client.get('/api/weekly-program?week_start=2026-08-17', headers={'Authorization': f'Bearer {self.student_token}'})
        self.assertEqual(res_s.status_code, 200)
        items = res_s.get_json()['items']
        self.assertGreater(len(items), 0)

        # Student marks task as TAMAMLANDI
        res_st = self.client.post(f'/api/weekly-program/{prog_id}/status', json={'status': 'TAMAMLANDI'}, headers={'Authorization': f'Bearer {self.student_token}'})
        self.assertEqual(res_st.status_code, 200)

        # Coach fetches Student 3 program and sees TAMAMLANDI status
        res_c = self.client.get('/api/weekly-program?student_id=3&week_start=2026-08-17', headers={'Authorization': f'Bearer {self.coach_token}'})
        items_c = res_c.get_json()['items']
        target_c = next((i for i in items_c if i['id'] == prog_id), None)
        self.assertEqual(target_c['status'], 'TAMAMLANDI')

    def test_03_student_isolation(self):
        # Fetch Student 2 (Elif Yılmaz) program
        res_e = self.client.get('/api/weekly-program?student_id=2&week_start=2026-08-17', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res_e.status_code, 200)
        items_e = res_e.get_json()['items']
        # Verify Elif does not see Mert's task titles
        for i in items_e:
            self.assertNotEqual(i['student_id'], 3)

if __name__ == '__main__':
    unittest.main()
