import sys
import os
import unittest

sys.path.insert(0, os.path.abspath('backend'))
from app import app

class WeeklyProgramRootCauseFixTest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

        # Coach Login
        res_c = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        self.assertEqual(res_c.status_code, 200)
        self.coach_token = res_c.get_json()['token']

        # Student Login (Mert Demir)
        res_s = self.client.post('/api/auth/login', json={'username': 'mert.demir', 'password': 'ogrenci123'})
        self.assertEqual(res_s.status_code, 200)
        self.student_token = res_s.get_json()['token']

    def test_01_api_endpoint_json_contract(self):
        res = self.client.get('/api/weekly-program?student_id=1&week_start=2026-08-10', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 200)
        self.assertTrue('application/json' in res.content_type)
        data = res.get_json()
        self.assertIn('items', data)
        self.assertIn('student', data)

    def test_02_refresh_10x_loop(self):
        for i in range(10):
            res = self.client.get('/api/weekly-program?student_id=1&week_start=2026-08-10', headers={'Authorization': f'Bearer {self.coach_token}'})
            self.assertEqual(res.status_code, 200)

    def test_03_empty_program_handling(self):
        # Fetch week with no items (e.g. 2029-01-01)
        res = self.client.get('/api/weekly-program?student_id=1&week_start=2029-01-01', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(len(data.get('items', [])), 0)

    def test_04_create_save_verify(self):
        # Clear specific week slot
        self.client.post('/api/weekly-program/clear', json={'student_id': 1, 'week_start': '2026-08-10'}, headers={'Authorization': f'Bearer {self.coach_token}'})

        payload = {
            'student_id': 1,
            'date': '2026-08-10',
            'day_of_week': 'Pazartesi',
            'start_time': '10:00',
            'end_time': '11:00',
            'title': 'Fizik - Vektörler 30 Soru',
            'status': 'PLANLANDI',
            'publication_status': 'PUBLISHED'
        }
        res = self.client.post('/api/weekly-program', json=payload, headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 200)

        # Refresh check
        res_check = self.client.get('/api/weekly-program?student_id=1&week_start=2026-08-10', headers={'Authorization': f'Bearer {self.coach_token}'})
        items = res_check.get_json()['items']
        target = next((i for i in items if i['title'] == 'Fizik - Vektörler 30 Soru'), None)
        self.assertIsNotNone(target)

if __name__ == '__main__':
    unittest.main()
