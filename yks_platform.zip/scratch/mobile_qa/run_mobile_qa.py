#!/usr/bin/env python3
# ============================================================
# MASTER MOBILE RESPONSIVE QA RUNNER
# Orchestrates 6 QA agents and generates reports under /reports/mobile/
# ============================================================

import sys
import os
import json
import argparse

# Add current script dir to path
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from agent1_layout import run_layout_agent
from agent2_interaction import run_interaction_agent
from agent3_navigation import run_navigation_agent
from agent4_form import run_form_agent
from agent5_visual import run_visual_agent
from agent6_final import run_final_qa_agent

def main():
    parser = argparse.ArgumentParser(description="Mobile Responsive QA Master Suite")
    parser.add_argument("--mode", choices=["mobile", "responsive", "visual", "full"], default="full", help="QA Test Execution Mode")
    args = parser.parse_args()

    project_root = os.path.abspath(os.path.join(script_dir, "..", ".."))
    app_js = os.path.join(project_root, "frontend", "app.js")
    styles_css = os.path.join(project_root, "frontend", "styles.css")
    index_html = os.path.join(project_root, "frontend", "index.html")
    reports_dir = os.path.join(project_root, "reports", "mobile")
    shots_dir = os.path.join(reports_dir, "screenshots")
    os.makedirs(shots_dir, exist_ok=True)

    print(f"🚀 Launching Mobile Responsive QA Suite (Mode: {args.mode.upper()})...")

    # Run Subagents
    l_res = run_layout_agent(app_js, index_html)
    i_res = run_interaction_agent(app_js, index_html)
    n_res = run_navigation_agent(app_js, index_html)
    f_res = run_form_agent(app_js, index_html)
    v_res = run_visual_agent(app_js, styles_css, shots_dir)

    # Save individual agent reports
    with open(os.path.join(reports_dir, "mobile-layout-report.json"), "w", encoding="utf-8") as f:
        json.dump(l_res, f, indent=2, ensure_ascii=False)
    with open(os.path.join(reports_dir, "mobile-interaction-report.json"), "w", encoding="utf-8") as f:
        json.dump(i_res, f, indent=2, ensure_ascii=False)
    with open(os.path.join(reports_dir, "mobile-navigation-report.json"), "w", encoding="utf-8") as f:
        json.dump(n_res, f, indent=2, ensure_ascii=False)
    with open(os.path.join(reports_dir, "mobile-form-report.json"), "w", encoding="utf-8") as f:
        json.dump(f_res, f, indent=2, ensure_ascii=False)
    with open(os.path.join(reports_dir, "mobile-visual-report.json"), "w", encoding="utf-8") as f:
        json.dump(v_res, f, indent=2, ensure_ascii=False)

    # Consolidated Final QA Agent Execution
    final_res = run_final_qa_agent(l_res, i_res, n_res, f_res, v_res, reports_dir)

    print("\n============================================================")
    print(f"📱 MOBILE RESPONSIVE QA SUMMARY SCORE: {final_res['overall_score']}%")
    print(f"📌 FINAL STATUS: {final_res['status']}")
    print(f"📄 Full HTML Report: {os.path.join(reports_dir, 'mobile-final-report.html')}")
    print("============================================================\n")

    if final_res["status"] == "FAIL":
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()
