# ============================================================
# AGENT 6: MOBILE FINAL QA / REPORT AGENT
# Consolidates all subagent reports, deduplicates, assigns score & PASS/FAIL
# ============================================================

import os
import json
import datetime

def generate_html_report(final_data, report_path):
    score = final_data["overall_score"]
    status_badge = '<span class="status-pass">🟢 PASS</span>' if final_data["status"] == "PASS" else '<span class="status-fail">🔴 FAIL</span>'
    
    issues_html = ""
    if not final_data["all_issues"]:
        issues_html = "<div class='no-issues'>🎉 Tebrikler! Hiçbir P0 veya P1 kritik mobil responsive hata tespit edilmedi.</div>"
    else:
        for idx, issue in enumerate(final_data["all_issues"], 1):
            sev = issue.get("severity", "P2")
            sev_class = "sev-p0" if sev == "P0" else "sev-p1" if sev == "P1" else "sev-p2"
            issues_html += f"""
            <div class="issue-card {sev_class}">
                <div class="issue-header">
                    <span class="sev-badge {sev_class}">{sev}</span>
                    <span class="issue-page">{issue.get('page', 'Global')}</span>
                    <span class="issue-vp">[{issue.get('viewport', 'All')}]</span>
                </div>
                <div class="issue-problem"><strong>Problem:</strong> {issue.get('problem', '')}</div>
                <div class="issue-expected"><strong>Beklenen:</strong> {issue.get('expected', '')}</div>
                <div class="issue-actual"><strong>Mevcut:</strong> {issue.get('actual', '')}</div>
                <div class="issue-fix"><strong>Çözüm Önerisi:</strong> <code>{issue.get('suggested_fix', '')}</code></div>
            </div>
            """

    html = f"""<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobile Responsive QA Master Report</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #08111F; color: #F8FAFC; margin: 0; padding: 32px; }}
        .container {{ max-width: 1100px; margin: 0 auto; }}
        h1 {{ font-size: 28px; margin-bottom: 8px; color: #FFFFFF; display: flex; align-items: center; justify-content: space-between; }}
        .subtitle {{ color: #94A3B8; font-size: 14px; margin-bottom: 32px; }}
        .metrics-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 32px; }}
        .metric-card {{ background: #0F1A2B; border: 1px solid #24324A; padding: 20px; border-radius: 12px; text-align: center; }}
        .metric-value {{ font-size: 32px; font-weight: 800; color: #60A5FA; margin-top: 4px; }}
        .metric-label {{ font-size: 12px; color: #94A3B8; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em; }}
        .status-pass {{ color: #34D399; font-weight: 800; font-size: 20px; }}
        .status-fail {{ color: #F87171; font-weight: 800; font-size: 20px; }}
        .section-title {{ font-size: 20px; font-weight: 700; margin-top: 40px; margin-bottom: 16px; border-bottom: 1px solid #24324A; padding-bottom: 8px; }}
        .issue-card {{ background: #0F1A2B; border-left: 4px solid #60A5FA; padding: 16px; margin-bottom: 16px; border-radius: 8px; border-top: 1px solid #24324A; border-right: 1px solid #24324A; border-bottom: 1px solid #24324A; }}
        .issue-card.sev-p0 {{ border-left-color: #EF4444; }}
        .issue-card.sev-p1 {{ border-left-color: #F97316; }}
        .issue-card.sev-p2 {{ border-left-color: #FBBF24; }}
        .sev-badge {{ padding: 2px 8px; border-radius: 4px; font-weight: 800; font-size: 11px; }}
        .sev-p0 {{ background: #7F1D1D; color: #FCA5A5; }}
        .sev-p1 {{ background: #7C2D12; color: #FDBA74; }}
        .sev-p2 {{ background: #78350F; color: #FDE68A; }}
        .issue-header {{ display: flex; gap: 12px; align-items: center; margin-bottom: 8px; }}
        .issue-page {{ font-weight: 700; color: #F8FAFC; }}
        .issue-vp {{ color: #94A3B8; font-size: 12px; }}
        .issue-problem, .issue-expected, .issue-actual, .issue-fix {{ font-size: 13px; margin-top: 6px; line-height: 1.5; }}
        .issue-fix code {{ background: #111D30; color: #38BDF8; padding: 2px 6px; border-radius: 4px; font-size: 12px; }}
        .no-issues {{ background: #064E3B; color: #A7F3D0; padding: 20px; border-radius: 12px; text-align: center; font-weight: 700; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>
            <span>📱 YKS & LGS KOÇLUK — MOBILE RESPONSIVE QA REPORT</span>
            {status_badge}
        </h1>
        <div class="subtitle">Rapor Oluşturulma Tarihi: {datetime.datetime.now().strftime('%d.%m.%Y %H:%M:%S')} • Test Viewportları: 320px - 1440px (9 Viewport)</div>

        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-label">GENEL QA SKORU</div>
                <div class="metric-value">{score}%</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">LAYOUT SKORU</div>
                <div class="metric-value">{final_data['scores']['layout']}%</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">INTERACTION SKORU</div>
                <div class="metric-value">{final_data['scores']['interaction']}%</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">NAVIGATION SKORU</div>
                <div class="metric-value">{final_data['scores']['navigation']}%</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">FORM & MODAL SKORU</div>
                <div class="metric-value">{final_data['scores']['forms']}%</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">VISUAL SKORU</div>
                <div class="metric-value">{final_data['scores']['visual']}%</div>
            </div>
        </div>

        <div class="section-title">DETAYLI BUG VE İYİLEŞTİRME LİSTESİ ({len(final_data['all_issues'])} HATA)</div>
        {issues_html}
    </div>
</body>
</html>
"""
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(html)

def generate_markdown_report(final_data, report_path):
    score = final_data["overall_score"]
    status = final_data["status"]
    
    md = f"""# 📱 MOBILE RESPONSIVE QA MASTER REPORT

- **Nihai Karar:** {'🟢 **PASS**' if status == 'PASS' else '🔴 **FAIL**'}
- **Genel Responsive QA Skoru:** **{score}%**
- **Tarih:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

### 📊 Alt Agent Skorları Matrix

| Test Kategorisi | Sorumlu Subagent | Skor |
| :--- | :--- | :---: |
| **Mobile Layout & Overflow** | Agent 1 (Mobile Layout Agent) | **{final_data['scores']['layout']}%** |
| **Mobile Interaction & Touch** | Agent 2 (Mobile Interaction Agent) | **{final_data['scores']['interaction']}%** |
| **Mobile Navigation & Router** | Agent 3 (Mobile Navigation Agent) | **{final_data['scores']['navigation']}%** |
| **Mobile Form & Modals** | Agent 4 (Mobile Form & Data Agent) | **{final_data['scores']['forms']}%** |
| **Mobile Visual & Theme Audit** | Agent 5 (Mobile Visual Regression Agent) | **{final_data['scores']['visual']}%** |

---

### 🐞 Tespit Edilen Bug & İyileştirme Listesi ({len(final_data['all_issues'])} Adet)

"""
    if not final_data["all_issues"]:
        md += "🎉 **Hiçbir P0/P1 kritik mobil responsive hata bulunmadı. Tüm mobil görünüm ve etkileşim testleri başarıyla geçti.**\n"
    else:
        for idx, issue in enumerate(final_data["all_issues"], 1):
            md += f"""#### {idx}. [{issue.get('severity', 'P2')}] {issue.get('page', 'Global')} ({issue.get('viewport', 'All')})
- **Problem:** {issue.get('problem', '')}
- **Beklenen:** {issue.get('expected', '')}
- **Mevcut:** {issue.get('actual', '')}
- **Önerilen Çözüm:** `{issue.get('suggested_fix', '')}`

"""

    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(md)

def run_final_qa_agent(layout_res, interaction_res, nav_res, form_res, visual_res, reports_dir):
    print("🤖 AGENT 6 (Mobile Final QA / Report Agent) consolidating subagent reports...")
    
    # 1. Merge all issues and deduplicate
    all_issues = []
    seen = set()

    for agent_res in [layout_res, interaction_res, nav_res, form_res, visual_res]:
        for issue in agent_res.get("issues", []):
            key = f"{issue.get('page')}_{issue.get('problem')}"
            if key not in seen:
                seen.add(key)
                all_issues.append(issue)

    # 2. Calculate category & overall scores
    scores = {
        "layout": layout_res.get("score", 100),
        "interaction": interaction_res.get("score", 100),
        "navigation": nav_res.get("score", 100),
        "forms": form_res.get("score", 100),
        "visual": visual_res.get("score", 100)
    }

    overall_score = round(sum(scores.values()) / len(scores), 1)

    # Status determination (FAIL if P0 or P1 exists, otherwise PASS)
    has_critical = any(i.get("severity") in ["P0", "P1"] for i in all_issues)
    status = "FAIL" if has_critical else "PASS"

    final_data = {
        "overall_score": overall_score,
        "status": status,
        "scores": scores,
        "all_issues": all_issues
    }

    # Generate html & md reports
    html_file = os.path.join(reports_dir, "mobile-final-report.html")
    md_file = os.path.join(reports_dir, "mobile-final-report.md")

    generate_html_report(final_data, html_file)
    generate_markdown_report(final_data, md_file)

    print(f"✅ Final reports successfully generated in {reports_dir}")
    return final_data

if __name__ == "__main__":
    from agent1_layout import run_layout_agent
    from agent2_interaction import run_interaction_agent
    from agent3_navigation import run_navigation_agent
    from agent4_form import run_form_agent
    from agent5_visual import run_visual_agent

    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    app_js = os.path.join(base_dir, "frontend", "app.js")
    styles_css = os.path.join(base_dir, "frontend", "styles.css")
    index_html = os.path.join(base_dir, "frontend", "index.html")
    reports_dir = os.path.join(base_dir, "reports", "mobile")
    shots_dir = os.path.join(reports_dir, "screenshots")
    os.makedirs(shots_dir, exist_ok=True)

    l_res = run_layout_agent(app_js, index_html)
    i_res = run_interaction_agent(app_js, index_html)
    n_res = run_navigation_agent(app_js, index_html)
    f_res = run_form_agent(app_js, index_html)
    v_res = run_visual_agent(app_js, styles_css, shots_dir)

    final = run_final_qa_agent(l_res, i_res, n_res, f_res, v_res, reports_dir)
    print(json.dumps(final, indent=2, ensure_ascii=False))
