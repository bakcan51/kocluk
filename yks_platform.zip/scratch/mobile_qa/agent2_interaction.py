# ============================================================
# AGENT 2: MOBILE INTERACTION AGENT
# Tests mobile touch targets (44x44px), drawer toggling, buttons
# ============================================================

import os
import json
import re

TOUCH_TARGET_MIN_PX = 44

def run_interaction_agent(app_js_path, html_path):
    print("🤖 AGENT 2 (Mobile Interaction Agent) starting interaction audit...")
    issues = []
    passed_count = 0

    with open(app_js_path, 'r', encoding='utf-8') as f:
        js = f.read()

    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    # 1. Audit Sidebar Drawer Toggle & Overlay Handlers
    has_toggle_sidebar = "toggleSidebar" in js or "toggleSidebar" in html or "toggleMobileSidebar" in js or "toggleMobileSidebar" in html
    has_sidebar_overlay = "sidebarOverlay" in html or "mobileSidebarOverlay" in html or "bg-black/50" in html or "bg-black/60" in html
    has_menu_autoclose = "closeSidebarOnMobile" in js or "toggleMobileSidebar" in js or "closeMobileSidebar" in js

    if has_toggle_sidebar:
        passed_count += 10
    else:
        issues.append({
            "page": "Global Sidebar",
            "viewport": "390x844 (Mobile)",
            "severity": "P1",
            "problem": "Sidebar drawer toggle button or function missing for mobile viewports",
            "expected": "Hamburger button should toggle mobile drawer menu",
            "actual": "Missing toggleSidebar implementation",
            "suggested_fix": "Add hamburger button with onclick='toggleSidebar()' to header"
        })

    if has_sidebar_overlay:
        passed_count += 10
    else:
        issues.append({
            "page": "Global Sidebar Overlay",
            "viewport": "390x844 (Mobile)",
            "severity": "P2",
            "problem": "Sidebar backdrop overlay is missing for mobile drawer",
            "expected": "Clicking outside sidebar on backdrop should close drawer",
            "actual": "Overlay element not detected in index.html",
            "suggested_fix": "Add <div id='sidebarOverlay' onclick='toggleSidebar()' class='fixed inset-0 bg-black/50 z-40 hidden md:hidden'></div>"
        })

    # 2. Audit Touch Target Padding & Heights on Interactive Buttons
    button_patterns = re.findall(r'<button[^>]*class=["\']([^"\']+)["\']', js) + re.findall(r'<button[^>]*class=["\']([^"\']+)["\']', html)
    small_targets = 0
    valid_targets = 0

    for b_class in button_patterns:
        # Check if button has proper mobile padding or dimensions (py-2, py-2.5, h-10, h-11, p-2.5, btn-primary, btn-secondary)
        if any(p in b_class for p in ['py-2', 'py-2.5', 'py-3', 'h-10', 'h-11', 'h-12', 'w-11', 'w-12', 'p-2.5', 'p-3', 'btn-primary', 'btn-secondary', 'px-3 py-1.5', 'px-4 py-2']):
            valid_targets += 1
        elif any(p in b_class for p in ['text-[10px]', 'p-0.5', 'p-1 ']):
            small_targets += 1

    passed_count += valid_targets

    if small_targets > 5:
        issues.append({
            "page": "Multiple Views",
            "viewport": "375x667 (Mobile)",
            "severity": "P3",
            "problem": f"Detected {small_targets} small icon/action buttons that may fail 44x44px touch target guidelines",
            "expected": "All touch targets should have at least 44x44px hit area or py-2 px-3 padding",
            "actual": f"{small_targets} small target buttons found",
            "suggested_fix": "Ensure py-2 px-3 or minimum p-2 padding on icon buttons"
        })

    total_checks = passed_count + len(issues)
    score = round((passed_count / max(1, total_checks)) * 100, 1)

    return {
        "agent": "Mobile Interaction Agent",
        "score": score,
        "valid_touch_targets": valid_targets,
        "small_touch_targets": small_targets,
        "issues": issues
    }

if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    app_js = os.path.join(base_dir, "frontend", "app.js")
    index_html = os.path.join(base_dir, "frontend", "index.html")
    res = run_interaction_agent(app_js, index_html)
    print(json.dumps(res, indent=2, ensure_ascii=False))
