# ============================================================
# DEMO ACADEMIC & COACHING DATA SEEDER — YKS & LGS PLATFORM
# Full Coaching Lifecycle: Exams, Homework, Program, Messages, Notifications
# ============================================================

import sqlite3
import os
from datetime import datetime, timedelta

DB_PATH = '/Users/burakakcan/.gemini/antigravity/scratch/yks_platform/yks_platform.db'

def ensure_columns(conn):
    cursor = conn.cursor()
    for table in ['mock_exams', 'exam_attempts', 'assignments', 'weekly_programs', 'messages', 'notifications']:
        cursor.execute(f"PRAGMA table_info({table})")
        cols = [r[1] for r in cursor.fetchall()]
        if 'is_demo' not in cols:
            cursor.execute(f"ALTER TABLE {table} ADD COLUMN is_demo INTEGER DEFAULT 0;")
            print(f"Added is_demo column to {table}")
    conn.commit()

def calc_net(correct, incorrect, is_lgs=False):
    penalty = 3.0 if is_lgs else 4.0
    return round(float(correct) - (float(incorrect) / penalty), 2)

def seed_demo_data():
    if not os.path.exists(DB_PATH):
        print(f"Error: Database not found at {DB_PATH}")
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    ensure_columns(conn)

    print("🧹 Cleaning previous demo records (is_demo = 1)...")
    # Clean previous demo records
    cursor.execute("SELECT id FROM mock_exams WHERE is_demo = 1;")
    demo_exam_ids = [r[0] for r in cursor.fetchall()]
    if demo_exam_ids:
        placeholders = ','.join('?' for _ in demo_exam_ids)
        cursor.execute(f"SELECT id FROM mock_exam_results WHERE mock_exam_id IN ({placeholders});", demo_exam_ids)
        result_ids = [r[0] for r in cursor.fetchall()]
        if result_ids:
            res_placeholders = ','.join('?' for _ in result_ids)
            cursor.execute(f"DELETE FROM mock_exam_topic_errors WHERE result_id IN ({res_placeholders});", result_ids)
        cursor.execute(f"DELETE FROM mock_exam_results WHERE mock_exam_id IN ({placeholders});", demo_exam_ids)
        cursor.execute(f"DELETE FROM mock_exams WHERE is_demo = 1;")

    cursor.execute("DELETE FROM exam_attempts WHERE is_demo = 1;")
    cursor.execute("DELETE FROM assignments WHERE is_demo = 1;")
    cursor.execute("DELETE FROM weekly_programs WHERE is_demo = 1;")
    cursor.execute("DELETE FROM messages WHERE is_demo = 1;")
    cursor.execute("DELETE FROM notifications WHERE is_demo = 1;")

    # Fix Ayşe Demir (student_id = 11): Change exam_system to YKS, track to SAYISAL
    cursor.execute("""
    UPDATE students 
    SET exam_system = 'YKS', track = 'SAYISAL' 
    WHERE id = 11 OR (user_id IN (SELECT id FROM users WHERE username = 'ayse.demir'));
    """)
    cursor.execute("DELETE FROM mock_exams WHERE student_id = 11 AND (exam_system = 'LGS' OR title LIKE '%LGS%');")
    cursor.execute("DELETE FROM exam_attempts WHERE student_id = 11 AND (exam_system = 'LGS' OR exam_name LIKE '%LGS%');")

    conn.commit()

    # Get Subject Mapping
    cursor.execute("SELECT id, name, exam_type, question_count, exam_system FROM subjects;")
    subjects_raw = cursor.fetchall()
    subj_map = {}
    for r in subjects_raw:
        subj_map[r[1]] = {"id": r[0], "name": r[1], "exam_type": r[2], "q_count": r[3], "exam_system": r[4]}

    # Get Topics Mapping
    cursor.execute("SELECT id, subject_id, name FROM topics;")
    topics_raw = cursor.fetchall()
    topics_by_subj = {}
    for r in topics_raw:
        s_id = r[1]
        if s_id not in topics_by_subj:
            topics_by_subj[s_id] = []
        topics_by_subj[s_id].append({"id": r[0], "name": r[2]})

    dates = ["2026-05-10", "2026-05-24", "2026-06-07", "2026-06-21", "2026-07-05", "2026-07-19", "2026-08-02", "2026-08-14"]
    publishers = ["3D Türkiye Geneli", "345 Yayınları", "Özdebir Türkiye Geneli", "Bilgi Sarmal", "Limit Yayınları", "Apotemi", "Orijinal", "Hız ve Renk"]

    # ------------------------------------------------------------
    # 1. EXAM SEEDING (BURAK, ELİF, ZEYNEP KAYA, CAN, KAAN, MERT, AYŞE DEMİR, ZEYNEP AK)
    # ------------------------------------------------------------
    def insert_exam_bundle(student_id, exam_system, exam_type, field, date_str, pub_name, score_list, coach_id=1):
        tot_c = sum(s[1] for s in score_list)
        tot_w = sum(s[2] for s in score_list)
        tot_b = sum(s[3] for s in score_list)
        tot_net = sum(calc_net(s[1], s[2], is_lgs=(exam_system == 'LGS')) for s in score_list)
        title = f"{pub_name} {exam_type} Denemesi"

        cursor.execute("""
        INSERT INTO mock_exams (student_id, title, exam_type, field, publisher, total_correct, total_wrong, total_blank, total_net, created_at, exam_system, created_by_coach_id, is_demo)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1);
        """, (student_id, title, exam_type, field, pub_name, tot_c, tot_w, tot_b, round(tot_net, 2), f"{date_str} 10:00:00", exam_system, coach_id))
        mock_id = cursor.lastrowid

        cursor.execute("""
        INSERT INTO exam_attempts (student_id, exam_system, exam_type, exam_name, publisher, exam_date, total_net, status, created_at, is_demo)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'COMPLETED', ?, 1);
        """, (student_id, exam_system, exam_type, title, pub_name, date_str, round(tot_net, 2), f"{date_str} 10:00:00"))

        for s_name, c, w, b in score_list:
            if s_name in subj_map:
                s_id = subj_map[s_name]["id"]
                s_net = calc_net(c, w, is_lgs=(exam_system == 'LGS'))
                cursor.execute("""
                INSERT INTO mock_exam_results (student_id, mock_exam_id, subject_id, correct, incorrect, empty, net, exam_date, analysis_done)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1);
                """, (student_id, mock_id, s_id, c, w, b, s_net, date_str))
                res_id = cursor.lastrowid

                if w > 0 and s_id in topics_by_subj and topics_by_subj[s_id]:
                    top_id = topics_by_subj[s_id][0]["id"]
                    cursor.execute("""
                    INSERT INTO mock_exam_topic_errors (result_id, topic_id, incorrect_count, empty_count)
                    VALUES (?, ?, ?, ?);
                    """, (res_id, top_id, w, b))

    # Profile 1: Burak Akcan (1)
    print("🌱 Seeding Exams for Burak Akcan (Çok Başarılı)...")
    burak_tyt = [
        {"date": dates[0], "pub": publishers[0], "scores": [("Türkçe", 32, 5, 3), ("Matematik", 29, 6, 5), ("Geometri", 8, 1, 1), ("Fizik", 6, 1, 0), ("Kimya", 6, 1, 0), ("Biyoloji", 5, 1, 0), ("Tarih", 4, 1, 0), ("Coğrafya", 4, 1, 0), ("Felsefe", 4, 1, 0), ("Din Kültürü", 5, 0, 0)]},
        {"date": dates[1], "pub": publishers[1], "scores": [("Türkçe", 34, 4, 2), ("Matematik", 31, 5, 4), ("Geometri", 9, 1, 0), ("Fizik", 6, 1, 0), ("Kimya", 7, 0, 0), ("Biyoloji", 5, 1, 0), ("Tarih", 4, 1, 0), ("Coğrafya", 4, 1, 0), ("Felsefe", 5, 0, 0), ("Din Kültürü", 5, 0, 0)]},
        {"date": dates[2], "pub": publishers[2], "scores": [("Türkçe", 35, 3, 2), ("Matematik", 33, 4, 3), ("Geometri", 9, 1, 0), ("Fizik", 7, 0, 0), ("Kimya", 6, 1, 0), ("Biyoloji", 6, 0, 0), ("Tarih", 5, 0, 0), ("Coğrafya", 4, 1, 0), ("Felsefe", 4, 1, 0), ("Din Kültürü", 5, 0, 0)]},
        {"date": dates[3], "pub": publishers[3], "scores": [("Türkçe", 36, 3, 1), ("Matematik", 35, 3, 2), ("Geometri", 10, 0, 0), ("Fizik", 7, 0, 0), ("Kimya", 7, 0, 0), ("Biyoloji", 6, 0, 0), ("Tarih", 5, 0, 0), ("Coğrafya", 5, 0, 0), ("Felsefe", 4, 1, 0), ("Din Kültürü", 5, 0, 0)]},
        {"date": dates[4], "pub": publishers[4], "scores": [("Türkçe", 37, 2, 1), ("Matematik", 36, 2, 2), ("Geometri", 10, 0, 0), ("Fizik", 7, 0, 0), ("Kimya", 7, 0, 0), ("Biyoloji", 6, 0, 0), ("Tarih", 5, 0, 0), ("Coğrafya", 5, 0, 0), ("Felsefe", 5, 0, 0), ("Din Kültürü", 5, 0, 0)]},
        {"date": dates[5], "pub": publishers[5], "scores": [("Türkçe", 38, 2, 0), ("Matematik", 37, 2, 1), ("Geometri", 10, 0, 0), ("Fizik", 7, 0, 0), ("Kimya", 7, 0, 0), ("Biyoloji", 6, 0, 0), ("Tarih", 5, 0, 0), ("Coğrafya", 5, 0, 0), ("Felsefe", 5, 0, 0), ("Din Kültürü", 5, 0, 0)]}
    ]
    burak_ayt = [
        {"date": dates[2], "pub": publishers[2], "scores": [("AYT Matematik", 24, 4, 2), ("AYT Geometri", 8, 1, 1), ("AYT Fizik", 10, 2, 2), ("AYT Kimya", 10, 2, 1), ("AYT Biyoloji", 10, 2, 1)]},
        {"date": dates[3], "pub": publishers[3], "scores": [("AYT Matematik", 26, 3, 1), ("AYT Geometri", 9, 1, 0), ("AYT Fizik", 11, 2, 1), ("AYT Kimya", 11, 1, 1), ("AYT Biyoloji", 11, 1, 1)]},
        {"date": dates[4], "pub": publishers[4], "scores": [("AYT Matematik", 27, 2, 1), ("AYT Geometri", 9, 1, 0), ("AYT Fizik", 12, 1, 1), ("AYT Kimya", 12, 1, 0), ("AYT Biyoloji", 12, 1, 0)]},
        {"date": dates[5], "pub": publishers[5], "scores": [("AYT Matematik", 28, 1, 1), ("AYT Geometri", 10, 0, 0), ("AYT Fizik", 13, 1, 0), ("AYT Kimya", 12, 1, 0), ("AYT Biyoloji", 12, 1, 0)]}
    ]
    for e in burak_tyt: insert_exam_bundle(1, 'YKS', 'TYT', 'SAYISAL', e['date'], e['pub'], e['scores'])
    for e in burak_ayt: insert_exam_bundle(1, 'YKS', 'AYT', 'SAYISAL', e['date'], e['pub'], e['scores'])

    # Profile 2: Elif Yılmaz (2)
    print("🌱 Seeding Exams for Elif Yılmaz (Başarılı)...")
    elif_tyt = [
        {"date": dates[0], "pub": publishers[0], "scores": [("Türkçe", 30, 6, 4), ("Matematik", 30, 5, 5), ("Geometri", 7, 2, 1), ("Fizik", 4, 2, 1), ("Kimya", 4, 2, 1), ("Biyoloji", 4, 1, 1), ("Tarih", 4, 1, 0), ("Coğrafya", 3, 1, 1), ("Felsefe", 4, 1, 0), ("Din Kültürü", 4, 1, 0)]},
        {"date": dates[1], "pub": publishers[1], "scores": [("Türkçe", 31, 5, 4), ("Matematik", 32, 4, 4), ("Geometri", 8, 1, 1), ("Fizik", 5, 1, 1), ("Kimya", 5, 1, 1), ("Biyoloji", 5, 1, 0), ("Tarih", 4, 1, 0), ("Coğrafya", 4, 1, 0), ("Felsefe", 4, 1, 0), ("Din Kültürü", 5, 0, 0)]},
        {"date": dates[2], "pub": publishers[2], "scores": [("Türkçe", 32, 5, 3), ("Matematik", 33, 3, 4), ("Geometri", 8, 1, 1), ("Fizik", 5, 2, 0), ("Kimya", 5, 1, 1), ("Biyoloji", 5, 1, 0), ("Tarih", 4, 1, 0), ("Coğrafya", 4, 1, 0), ("Felsefe", 4, 1, 0), ("Din Kültürü", 5, 0, 0)]},
        {"date": dates[3], "pub": publishers[3], "scores": [("Türkçe", 33, 4, 3), ("Matematik", 34, 3, 3), ("Geometri", 9, 1, 0), ("Fizik", 6, 1, 0), ("Kimya", 6, 1, 0), ("Biyoloji", 5, 1, 0), ("Tarih", 5, 0, 0), ("Coğrafya", 4, 1, 0), ("Felsefe", 5, 0, 0), ("Din Kültürü", 5, 0, 0)]}
    ]
    for e in elif_tyt: insert_exam_bundle(2, 'YKS', 'TYT', 'SAYISAL', e['date'], e['pub'], e['scores'])

    # Profile 3: Zeynep Kaya (4)
    print("🌱 Seeding Exams for Zeynep Kaya (Orta / Gelişen)...")
    zeynep_tyt = [
        {"date": dates[0], "pub": publishers[0], "scores": [("Türkçe", 26, 8, 6), ("Matematik", 14, 10, 16), ("Geometri", 2, 4, 4), ("Fizik", 1, 3, 3), ("Kimya", 1, 3, 3), ("Biyoloji", 1, 3, 2), ("Tarih", 3, 2, 0), ("Coğrafya", 3, 2, 0), ("Felsefe", 3, 2, 0), ("Din Kültürü", 4, 1, 0)]},
        {"date": dates[1], "pub": publishers[1], "scores": [("Türkçe", 27, 7, 6), ("Matematik", 15, 9, 16), ("Geometri", 3, 3, 4), ("Fizik", 1, 2, 4), ("Kimya", 1, 2, 4), ("Biyoloji", 1, 2, 3), ("Tarih", 3, 1, 1), ("Coğrafya", 3, 1, 1), ("Felsefe", 3, 1, 1), ("Din Kültürü", 4, 1, 0)]},
        {"date": dates[2], "pub": publishers[2], "scores": [("Türkçe", 28, 6, 6), ("Matematik", 16, 8, 16), ("Geometri", 3, 3, 4), ("Fizik", 2, 2, 3), ("Kimya", 2, 2, 3), ("Biyoloji", 2, 2, 2), ("Tarih", 4, 1, 0), ("Coğrafya", 3, 1, 1), ("Felsefe", 4, 1, 0), ("Din Kültürü", 4, 1, 0)]}
    ]
    for e in zeynep_tyt: insert_exam_bundle(4, 'YKS', 'TYT', 'EA', e['date'], e['pub'], e['scores'])

    # Profile 4: Can Öztürk (5)
    print("🌱 Seeding Exams for Can Öztürk (Orta / Dalgalı)...")
    can_tyt = [
        {"date": dates[0], "pub": publishers[0], "scores": [("Türkçe", 28, 8, 4), ("Matematik", 22, 8, 10), ("Geometri", 4, 3, 3), ("Fizik", 2, 3, 2), ("Kimya", 2, 3, 2), ("Biyoloji", 2, 2, 2), ("Tarih", 3, 2, 0), ("Coğrafya", 3, 2, 0), ("Felsefe", 3, 2, 0), ("Din Kültürü", 4, 1, 0)]},
        {"date": dates[1], "pub": publishers[1], "scores": [("Türkçe", 31, 5, 4), ("Matematik", 24, 6, 10), ("Geometri", 5, 2, 3), ("Fizik", 2, 2, 3), ("Kimya", 2, 2, 3), ("Biyoloji", 2, 2, 2), ("Tarih", 4, 1, 0), ("Coğrafya", 4, 1, 0), ("Felsefe", 4, 1, 0), ("Din Kültürü", 4, 1, 0)]},
        {"date": dates[2], "pub": publishers[2], "scores": [("Türkçe", 26, 10, 4), ("Matematik", 20, 10, 10), ("Geometri", 3, 4, 3), ("Fizik", 2, 3, 2), ("Kimya", 2, 3, 2), ("Biyoloji", 2, 2, 2), ("Tarih", 3, 2, 0), ("Coğrafya", 3, 2, 0), ("Felsefe", 3, 2, 0), ("Din Kültürü", 4, 1, 0)]}
    ]
    for e in can_tyt: insert_exam_bundle(5, 'YKS', 'TYT', 'EA', e['date'], e['pub'], e['scores'])

    # Profile 5: Kaan Tekin (10)
    print("🌱 Seeding Exams for Kaan Tekin (Düşük / Yükselen)...")
    kaan_tyt = [
        {"date": dates[0], "pub": publishers[0], "scores": [("Türkçe", 22, 10, 8), ("Matematik", 8, 12, 20), ("Geometri", 1, 4, 5), ("Fizik", 1, 4, 2), ("Kimya", 1, 4, 2), ("Biyoloji", 1, 3, 2), ("Tarih", 2, 3, 0), ("Coğrafya", 2, 3, 0), ("Felsefe", 2, 3, 0), ("Din Kültürü", 3, 2, 0)]},
        {"date": dates[1], "pub": publishers[1], "scores": [("Türkçe", 23, 9, 8), ("Matematik", 9, 11, 20), ("Geometri", 2, 3, 5), ("Fizik", 1, 3, 3), ("Kimya", 1, 3, 3), ("Biyoloji", 1, 3, 2), ("Tarih", 2, 2, 1), ("Coğrafya", 2, 2, 1), ("Felsefe", 2, 2, 1), ("Din Kültürü", 3, 2, 0)]}
    ]
    for e in kaan_tyt: insert_exam_bundle(10, 'YKS', 'TYT', 'SAYISAL', e['date'], e['pub'], e['scores'])

    # Profile 6: Mert Demir (3)
    print("🌱 Seeding Exams for Mert Demir (Düşük / Riskli)...")
    mert_tyt = [
        {"date": dates[0], "pub": publishers[0], "scores": [("Türkçe", 28, 6, 6), ("Matematik", 18, 8, 14), ("Geometri", 3, 3, 4), ("Fizik", 2, 3, 2), ("Kimya", 2, 3, 2), ("Biyoloji", 2, 2, 2), ("Tarih", 3, 2, 0), ("Coğrafya", 3, 2, 0), ("Felsefe", 3, 2, 0), ("Din Kültürü", 4, 1, 0)]},
        {"date": dates[1], "pub": publishers[1], "scores": [("Türkçe", 27, 7, 6), ("Matematik", 16, 9, 15), ("Geometri", 2, 4, 4), ("Fizik", 2, 3, 2), ("Kimya", 2, 3, 2), ("Biyoloji", 2, 2, 2), ("Tarih", 3, 2, 0), ("Coğrafya", 3, 2, 0), ("Felsefe", 3, 2, 0), ("Din Kültürü", 4, 1, 0)]},
        {"date": dates[2], "pub": publishers[2], "scores": [("Türkçe", 26, 8, 6), ("Matematik", 15, 10, 15), ("Geometri", 2, 4, 4), ("Fizik", 1, 4, 2), ("Kimya", 1, 4, 2), ("Biyoloji", 1, 3, 2), ("Tarih", 3, 2, 0), ("Coğrafya", 3, 2, 0), ("Felsefe", 3, 2, 0), ("Din Kültürü", 3, 2, 0)]}
    ]
    for e in mert_tyt: insert_exam_bundle(3, 'YKS', 'TYT', 'SAYISAL', e['date'], e['pub'], e['scores'])

    # ------------------------------------------------------------
    # 2. ASSIGNMENTS SEEDING (ÖDEVLER)
    # Statuses: COMPLETED, IN_PROGRESS, PENDING, LATE
    # Priorities: DUSUK, ORTA, YUKSEK
    # ------------------------------------------------------------
    print("🌱 Seeding Assignments (Ödevler)...")
    assignments_data = [
        # Burak Akcan (student_id = 1) — %90+ Completed
        (1, 1, 1, 'TYT Matematik — Fonksiyonlar & Polinomlar Testi', 2, 16, 100, 100, '2026-08-10', '2026-08-10', 'COMPLETED', 'YUKSEK', 'Mükemmel performans, tebrikler!'),
        (1, 1, 1, 'AYT Fizik — Elektriksel Alan & Potansiyel', 13, 38, 80, 80, '2026-08-12', '2026-08-12', 'COMPLETED', 'YUKSEK', 'Konu tam kavranmış.'),
        (1, 1, 1, 'AYT Matematik — Türev & Uygulamaları', 11, 32, 120, 120, '2026-08-14', '2026-08-14', 'COMPLETED', 'ORTA', 'Türev grafikleri eksiksiz çözülmüş.'),
        (1, 1, 1, 'AYT Biyoloji — Genetik Şifre & Protein Sentezi', 15, 40, 60, 40, '2026-08-18', None, 'IN_PROGRESS', 'ORTA', 'Çözüme devam ediliyor.'),
        (1, 1, 1, 'TYT Türkçe — Paragrafta Ana Fikir Kampı', 1, 3, 80, 80, '2026-08-08', '2026-08-08', 'COMPLETED', 'DUSUK', 'Hız kazanıldı.'),

        # Elif Yılmaz (student_id = 2) — Mostly Completed & Pending
        (1, 1, 2, 'TYT Matematik — Sayı & Kesir Problemleri', 2, 12, 100, 100, '2026-08-11', '2026-08-11', 'COMPLETED', 'YUKSEK', 'Süre kullanımı gayet iyi.'),
        (1, 1, 2, 'AYT Matematik — Logaritma & Diziler', 11, 29, 80, 80, '2026-08-13', '2026-08-13', 'COMPLETED', 'ORTA', 'Başarılı.'),
        (1, 1, 2, 'AYT Fizik — Manyetik Alan & İndüksiyon', 13, 39, 80, 0, '2026-08-19', None, 'PENDING', 'YUKSEK', 'Fizik tekrarı için bu teste öncelik verelim.'),
        (1, 1, 2, 'AYT Kimya — Kimyasal Denge', 14, 30, 60, 0, '2026-08-20', None, 'PENDING', 'ORTA', 'Formül tekrarı sonrası çözülecek.'),

        # Zeynep Kaya (student_id = 4) — Completed & Pending
        (1, 1, 4, 'TYT Türkçe — Paragrafta Yapı & Akış', 1, 3, 90, 90, '2026-08-10', '2026-08-10', 'COMPLETED', 'ORTA', 'Güzel ilerleme.'),
        (1, 1, 4, 'TYT Matematik — Oran-Orantı & Problemler', 2, 11, 80, 80, '2026-08-12', '2026-08-12', 'COMPLETED', 'YUKSEK', 'Net artışına katkı sağladı.'),
        (1, 1, 4, 'AYT Edebiyat — Şiir Bilgisi & Edebi Sanatlar', 16, 20, 70, 70, '2026-08-14', '2026-08-14', 'COMPLETED', 'ORTA', 'Tamamlandı.'),
        (1, 1, 4, 'AYT Matematik — Fonksiyon Denklemleri', 11, 24, 60, 0, '2026-08-18', None, 'PENDING', 'YUKSEK', 'Önemli konu.'),

        # Can Öztürk (student_id = 5) — Completed, In Progress, Late
        (1, 1, 5, 'TYT Türkçe — Cümlenin Ögeleri Kampı', 1, 6, 80, 80, '2026-08-09', '2026-08-09', 'COMPLETED', 'ORTA', 'Tamamlandı.'),
        (1, 1, 5, 'TYT Matematik — Hız & Yüzde-Kâr-Zarar', 2, 14, 70, 35, '2026-08-17', None, 'IN_PROGRESS', 'YUKSEK', 'Yarısını çözdün, devam et.'),
        (1, 1, 5, 'AYT Matematik — Polinomlar Soru Bankası', 11, 24, 80, 0, '2026-08-05', None, 'LATE', 'YUKSEK', 'Teslim tarihi geçti! Acil tamamlanmalı.'),
        (1, 1, 5, 'AYT Tarih-1 — Milli Mücadele Dönemi', 17, 25, 50, 0, '2026-08-06', None, 'LATE', 'ORTA', 'Tarih tekrarı aksatıldı.'),

        # Kaan Tekin (student_id = 10) — Pending & In Progress
        (1, 1, 10, 'TYT Türkçe — Sözcükte Anlam Testi', 1, 1, 80, 80, '2026-08-12', '2026-08-12', 'COMPLETED', 'ORTA', 'Başarılı başlangıç.'),
        (1, 1, 10, 'TYT Matematik — Temel Kavramlar & Sayılar', 2, 7, 80, 40, '2026-08-17', None, 'IN_PROGRESS', 'YUKSEK', 'Yarısı tamamlandı.'),
        (1, 1, 10, 'TYT Fizik — Fizik Bilimine Giriş & Madde', 4, 34, 50, 0, '2026-08-19', None, 'PENDING', 'ORTA', 'Bekliyor.'),

        # Mert Demir (student_id = 3) — Late & Pending (Riskli Öğrenci)
        (1, 1, 3, 'TYT Matematik — Problemler Fasikülü 4', 2, 12, 120, 10, '2026-08-01', None, 'LATE', 'YUKSEK', 'Çok geride kaldın, acil telafi et!'),
        (1, 1, 3, 'TYT Fizik — Hareket & Kuvvet Testi 2', 4, 36, 80, 0, '2026-08-05', None, 'LATE', 'YUKSEK', 'İkinci kez gecikti.'),
        (1, 1, 3, 'TYT Kimya — Mol Kavramı & Hesaplamalar', 5, 27, 70, 0, '2026-08-07', None, 'LATE', 'ORTA', 'Ödev teslim tarihi geçti.'),
        (1, 1, 3, 'TYT Biyoloji — Hücre Bölünmeleri & Kalıtım', 6, 30, 60, 0, '2026-08-09', None, 'LATE', 'ORTA', 'Gecikmede.'),
        (1, 1, 3, 'TYT Matematik — Temel Kavramlar Tekrarı', 2, 7, 100, 0, '2026-08-18', None, 'PENDING', 'YUKSEK', 'Düşüşü önlemek için bu ödev şart.'),
        (1, 1, 3, 'TYT Türkçe — Paragraf Kampı Gün 5', 1, 3, 50, 50, '2026-08-11', '2026-08-11', 'COMPLETED', 'DUSUK', 'Tamamlandı.')
    ]

    for a in assignments_data:
        cursor.execute("""
        INSERT INTO assignments (coach_id, created_by_coach_id, student_id, title, subject_id, topic_id, target_question_count, completed_count, due_date, completed_at, status, priority, coach_note, is_demo)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1);
        """, a)

    # ------------------------------------------------------------
    # 3. WEEKLY PROGRAMS SEEDING (HAFTALIK PROGRAM)
    # ------------------------------------------------------------
    print("🌱 Seeding Weekly Programs (Haftalık Program)...")
    day_date_map = {
        "Pazartesi": "2026-08-10",
        "Salı": "2026-08-11",
        "Çarşamba": "2026-08-12",
        "Perşembe": "2026-08-13",
        "Cuma": "2026-08-14",
        "Cumartesi": "2026-08-15",
        "Pazar": "2026-08-16"
    }
    
    status_map = {
        "COMPLETED": "TAMAMLANDI",
        "IN_PROGRESS": "DEVAM_EDIYOR",
        "PENDING": "PLANLANDI"
    }

    def seed_student_program(student_id, slots):
        for day, start_t, end_t, title, s_id, status_val, study_tp in slots:
            dt = day_date_map.get(day, "2026-08-10")
            st_val = status_map.get(status_val, "PLANLANDI")
            cursor.execute("""
            INSERT INTO weekly_programs (student_id, created_by_coach_id, date, day_of_week, start_time, end_time, title, subject_id, status, study_type, week_start_date, publication_status, completion_status, is_demo)
            VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?, ?, '2026-08-10', 'PUBLISHED', ?, 1);
            """, (student_id, dt, day, start_t, end_t, title, s_id, st_val, study_tp, st_val))

    # Burak Akcan Program
    seed_student_program(1, [
        ("Pazartesi", "09:00", "10:30", "TYT Matematik — Problemler Kampı", 2, "COMPLETED", "SORU_COZUMU"),
        ("Pazartesi", "11:00", "12:30", "AYT Fizik — Elektrik Tekrarı", 13, "COMPLETED", "KONU_ANLATIMI"),
        ("Salı", "09:00", "10:30", "TYT Türkçe — Paragraf Hız Testi", 1, "COMPLETED", "SORU_COZUMU"),
        ("Salı", "14:00", "16:00", "AYT Matematik — Türev Soru Bankası", 11, "COMPLETED", "SORU_COZUMU"),
        ("Çarşamba", "09:00", "12:00", "Kurumsal TYT Deneme Sınavı", 1, "COMPLETED", "DENEME"),
        ("Perşembe", "10:00", "12:00", "AYT Kimya & Biyoloji Etütü", 14, "IN_PROGRESS", "SORU_COZUMU"),
        ("Cuma", "14:00", "16:00", "Haftalık Hata & Konu Analizi", 2, "PENDING", "ANALIZ")
    ])

    # Mert Demir Program (Riskli - Telafi odaklı)
    seed_student_program(3, [
        ("Pazartesi", "09:00", "10:00", "TYT Matematik — Problemler Telafi Çalışması", 2, "PENDING", "TELAFİ"),
        ("Pazartesi", "10:30", "11:30", "TYT Fizik — Hareket Geciken Ödev", 4, "PENDING", "TELAFİ"),
        ("Salı", "09:00", "10:30", "TYT Türkçe — Paragraf Rutini", 1, "COMPLETED", "SORU_COZUMU"),
        ("Salı", "14:00", "15:30", "TYT Matematik — Temel Kavramlar Yanlış Analizi", 2, "PENDING", "ANALIZ"),
        ("Çarşamba", "09:00", "12:00", "TYT Deneme Sınavı", 1, "COMPLETED", "DENEME"),
        ("Perşembe", "10:00", "11:30", "Aksayan Ödevleri Telafi Etme Etütü", 2, "PENDING", "TELAFİ")
    ])

    # ------------------------------------------------------------
    # 4. MESSAGES SEEDING (MESAJLAŞMA & UNREAD STATES)
    # Coach User ID = 2 (Ümmü Akcan)
    # ------------------------------------------------------------
    print("🌱 Seeding Messages (Mesajlar)...")
    messages_data = [
        # Burak Akcan (User ID 4) — 2 unread messages from Coach to Burak
        (2, 4, 'Son 5 denemendeki istikrarlı matematik yükselişin harika! AYT Fizik elektrik konusunu da bu hafta tamamlayalım.', 0, '2026-08-15 14:00:00'),
        (2, 4, 'Türev ödevinin detaylarını kontrol ettim, başarı oranı %95.', 0, '2026-08-15 16:30:00'),

        # Elif Yılmaz (User ID 5) — 1 unread message from Coach to Elif
        (2, 5, 'Elif selam, Fizik soru bankasındaki Manyetizma testini programa ekledim. Takıldığın soruları yarın inceleyelim.', 0, '2026-08-15 15:10:00'),

        # Zeynep Kaya (User ID 7) — 0 unread messages (is_read = 1)
        (2, 7, 'Zeynep Edebiyat ve Türkçe netlerindeki artış çok güzel. Haftalık plana uyum tam.', 1, '2026-08-14 11:00:00'),
        (7, 2, 'Teşekkürler hocam, bu hafta Matematik fonksiyonlara ağırlık veriyorum.', 1, '2026-08-14 11:15:00'),

        # Can Öztürk (User ID 8) — 3 unread messages from Coach to Can
        (2, 8, 'Can merhaba, bu haftaki denemede Türkçe süre sıkıntısı yaşadığını fark ettim.', 0, '2026-08-15 09:00:00'),
        (2, 8, 'Paragraf çözerken kronometre kullanmanı öneriyorum.', 0, '2026-08-15 09:02:00'),
        (2, 8, 'Geciken matematik ödevini bu akşam tamamlayabilir misin?', 0, '2026-08-15 18:00:00'),

        # Kaan Tekin (User ID 13) — 1 unread message from Coach to Kaan
        (2, 13, 'Kaan son denemede netini 55\'e çıkardın, tebrikler! Temel kavramlar çalışmasını aksatma.', 0, '2026-08-15 12:00:00'),

        # Mert Demir (User ID 6) — 4 unread messages from Coach to Mert (Riskli Öğrenci)
        (2, 6, 'Mert selam, son 3 denemedeki net düşüşü ve 3 geciken ödevin dikkatimi çekti.', 0, '2026-08-15 10:00:00'),
        (2, 6, 'Bugünkü programa 45 dakikalık telafi çalışması ekledim.', 0, '2026-08-15 10:05:00'),
        (2, 6, 'Özellikle matematik problemlerinde nerede zorlanıyorsun, mesajla iletir misin?', 0, '2026-08-15 11:30:00'),
        (2, 6, 'Bugün saat 17:00\'ye kadar geciken ödevleri tamamlamanı bekliyorum.', 0, '2026-08-15 14:45:00')
    ]

    for m in messages_data:
        cursor.execute("""
        INSERT INTO messages (sender_id, receiver_id, content, is_read, sent_at, is_demo)
        VALUES (?, ?, ?, ?, ?, 1);
        """, m)

    # ------------------------------------------------------------
    # 5. NOTIFICATIONS SEEDING (BİLDİRİMLER)
    # ------------------------------------------------------------
    print("🌱 Seeding Notifications (Bildirimler)...")
    notifications_data = [
        (4, 2, 'ASSIGNMENT', 'Yeni Ödev Atandı', 'Koçunuz yeni bir AYT Biyoloji ödevi atadı.', 'assignment', 1, 0, '2026-08-15 10:00:00'),
        (6, 2, 'WARNING', 'Geciken Ödev Uyarısı', 'TYT Matematik Problemler Fasikülü 4 ödevinin teslim tarihi geçti!', 'assignment', 5, 0, '2026-08-15 10:05:00'),
        (2, 4, 'SYSTEM', 'Ödev Tamamlandı', 'Burak Akcan TYT Matematik ödevini tamamladı.', 'assignment', 1, 0, '2026-08-15 11:00:00')
    ]

    for n in notifications_data:
        cursor.execute("""
        INSERT INTO notifications (recipient_user_id, actor_user_id, type, title, message, entity_type, entity_id, is_read, created_at, is_demo)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1);
        """, n)

    conn.commit()
    conn.close()
    print("✅ FULL DEMO COACHING LIFECYCLE SEEDED SUCCESSFULLY!")

if __name__ == "__main__":
    seed_demo_data()
