APP_PATH = "/Users/burakakcan/.gemini/antigravity/scratch/yks_platform/frontend/app.js"

with open(APP_PATH, "r", encoding="utf-8") as f:
    lines = f.readlines()

brace_stack = []

for idx, line in enumerate(lines, 1):
    # ignore string literals and comments for brace counting
    i = 0
    while i < len(line):
        ch = line[i]
        if ch in '{(':
            brace_stack.append((ch, idx, line.strip()))
        elif ch in '}':
            if not brace_stack:
                print(f"L{idx}: Unmatched closing brace '}}'")
            else:
                top, tline, _ = brace_stack[-1]
                if top == '{':
                    brace_stack.pop()
                else:
                    print(f"L{idx}: Mismatched closing brace '}}' for opening '{top}' at L{tline}")
        elif ch == ')':
            if not brace_stack:
                print(f"L{idx}: Unmatched closing paren ')'")
            else:
                top, tline, _ = brace_stack[-1]
                if top == '(':
                    brace_stack.pop()
                else:
                    print(f"L{idx}: Mismatched closing paren ')' for opening '{top}' at L{tline}")
        i += 1

print(f"Remaining unmatched on stack at end of file: {len(brace_stack)}")
for ch, lnum, lstr in brace_stack[-10:]:
    print(f"Unmatched '{ch}' from L{lnum}: {lstr}")

