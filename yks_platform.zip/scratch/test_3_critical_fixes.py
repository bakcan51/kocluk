import sys
import os
import json
import unittest

sys.path.insert(0, os.path.abspath('backend'))
from app import app

class ThreeCriticalFixesTest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

        # Coach Login
        res = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        self.assertEqual(res.status_code, 200)
        self.coach_token = res.get_json()['token']

        # Student Login (Burak Akcan)
        res = self.client.post('/api/auth/login', json={'username': 'burak.akcan', 'password': 'ogrenci123'})
        self.assertEqual(res.status_code, 200)
        self.student1_token = res.get_json()['token']

    def test_01_assignments_api_returns_json_200(self):
        # Fetch assignments as coach
        res = self.client.get('/api/odevler?student_id=ALL&status=ALL&sort=NEWEST', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 200)
        self.assertIn('application/json', res.content_type)
        data = res.get_json()
        self.assertIn('assignments', data)
        self.assertIsInstance(data['assignments'], list)

        # Fetch assignments as student
        res_st = self.client.get('/api/odevler?status=ALL', headers={'Authorization': f'Bearer {self.student1_token}'})
        self.assertEqual(res_st.status_code, 200)
        self.assertIn('application/json', res_st.content_type)

    def test_02_unread_messages_badge_calculation(self):
        # Fetch unread summary for coach
        res = self.client.get('/api/mesajlar/unread-summary', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn('total_unread', data)
        # Coach has 0 unread chat messages
        self.assertEqual(data['total_unread'], 0)

    def test_03_student_detail_isolation_and_routing(self):
        # Fetch single student detail for Student 4 (Zeynep Kaya)
        res = self.client.get('/api/students/4', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['student']['id'], 4)
        self.assertEqual(data['student']['name'], 'Zeynep Kaya')

        # Invalid student ID 9999 returns 404
        res_404 = self.client.get('/api/students/9999', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res_404.status_code, 404)

if __name__ == '__main__':
    unittest.main()
