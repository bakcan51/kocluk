import os
import sys
import json
import unittest

sys.path.insert(0, os.path.abspath('backend'))
from app import app

class ComprehensiveSystemQATest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
        # Admin login
        res = self.client.post('/api/auth/login', json={'username': 'admin', 'password': 'password123'})
        self.assertEqual(res.status_code, 200)
        self.admin_token = res.get_json()['token']

        # Coach login (ummu.akcan, user_id=2, coach_id=1)
        res = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        self.assertEqual(res.status_code, 200)
        self.coach_token = res.get_json()['token']

        # Student 1 login (burak.akcan, user_id=4, student_id=1)
        res = self.client.post('/api/auth/login', json={'username': 'burak.akcan', 'password': 'ogrenci123'})
        self.assertEqual(res.status_code, 200)
        self.student1_token = res.get_json()['token']

    def test_01_login_authentication_and_backdoor_removal(self):
        # Valid logins
        for username, password, role in [('admin', 'password123', 'ADMIN'), ('ummu.akcan', 'password123', 'COACH'), ('burak.akcan', 'ogrenci123', 'STUDENT')]:
            res = self.client.post('/api/auth/login', json={'username': username, 'password': password})
            self.assertEqual(res.status_code, 200)
            data = res.get_json()
            self.assertTrue(data['success'])
            self.assertEqual(data['user']['role'], role)

        # Invalid password
        res = self.client.post('/api/auth/login', json={'username': 'admin', 'password': 'wrongpassword'})
        self.assertEqual(res.status_code, 401)

        # Removed backdoor passwords must be rejected
        res = self.client.post('/api/auth/login', json={'username': 'admin', 'password': 'admin123'})
        self.assertEqual(res.status_code, 401)

    def test_02_student_mufredat_bola_isolation(self):
        # Student 1 requesting Student 2's curriculum data via URL query param
        res = self.client.get('/api/mufredat?student_id=2', headers={'Authorization': f'Bearer {self.student1_token}'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        # Must return Student 1's data (Burak Akcan), not Elif Yılmaz
        self.assertEqual(data['student_id'], 1)
        self.assertIn('Burak', data['student_name'])

    def test_03_student_soru_takibi_bola_isolation(self):
        # Student 1 requesting Student 2's question logs
        res = self.client.get('/api/soru-takibi?student_id=2', headers={'Authorization': f'Bearer {self.student1_token}'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        # Ensure returned logs belong strictly to student_id 1
        for log in data.get('question_logs', []):
            self.assertEqual(log['student_id'], 1)

    def test_04_coach_ownership_authorization(self):
        # Coach requesting unowned student (e.g. non-existent or unassigned ID 999)
        res = self.client.get('/api/deneme?student_id=999', headers={'Authorization': f'Bearer {self.coach_token}'})
        # Should return 403 Forbidden instead of silent fallback
        self.assertEqual(res.status_code, 403)

    def test_05_topic_status_update_no_nameerror(self):
        # Topic status update POST
        res = self.client.post('/api/mufredat/konu-durum-guncelle', 
                               json={'student_id': 1, 'curriculum_id': 10, 'status': 'COMPLETED'},
                               headers={'Authorization': f'Bearer {self.student1_token}'})
        self.assertEqual(res.status_code, 200)

    def test_06_unprotected_endpoints_rbac(self):
        # Student trying to assign resource
        res = self.client.post('/api/kaynaklar/assign', json={'student_id': 1, 'resource_id': 1}, headers={'Authorization': f'Bearer {self.student1_token}'})
        self.assertEqual(res.status_code, 403)

        # Student trying to update student track field
        res = self.client.post('/api/student/update-field', json={'student_id': 1, 'field': 'SOZEL'}, headers={'Authorization': f'Bearer {self.student1_token}'})
        self.assertEqual(res.status_code, 403)

if __name__ == '__main__':
    unittest.main()
