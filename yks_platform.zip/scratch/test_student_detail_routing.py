import sys
import os
import json
import unittest

sys.path.insert(0, os.path.abspath('backend'))
from app import app

class StudentDetailQATest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
        # Login as coach ummu.akcan
        res = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        self.assertEqual(res.status_code, 200)
        self.coach_token = res.get_json()['token']

        # Login as Burak Akcan (student_id = 1)
        res = self.client.post('/api/auth/login', json={'username': 'burak.akcan', 'password': 'ogrenci123'})
        self.assertEqual(res.status_code, 200)
        self.student1_token = res.get_json()['token']

    def test_01_get_single_student_detail_authorized(self):
        # Coach fetching Student 1 (Burak Akcan)
        res = self.client.get('/api/students/1', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn('student', data)
        self.assertEqual(data['student']['id'], 1)
        self.assertIn('Burak', data['student']['name'])

    def test_02_get_single_student_detail_invalid_id(self):
        # Coach fetching non-existent student 9999
        res = self.client.get('/api/students/9999', headers={'Authorization': f'Bearer {self.coach_token}'})
        self.assertEqual(res.status_code, 404)

    def test_03_student_cannot_access_other_student(self):
        # Student 1 trying to access Student 2
        res = self.client.get('/api/students/2', headers={'Authorization': f'Bearer {self.student1_token}'})
        self.assertEqual(res.status_code, 403)

if __name__ == '__main__':
    unittest.main()
