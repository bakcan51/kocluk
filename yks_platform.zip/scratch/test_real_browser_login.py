import asyncio
import os
import sys

# Test Playwright browser interaction if available or python urllib
async def main():
    try:
        from playwright.async_api import async_playwright
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()

            console_logs = []
            page.on("console", lambda msg: console_logs.append(f"[{msg.type}] {msg.text}"))

            print("Navigating to http://127.0.0.1:5005/#/login...")
            await page.goto("http://127.0.0.1:5005/#/login")
            await page.wait_for_timeout(1000)

            # Check initial inputs
            u_val = await page.input_value("#loginEmail")
            p_val = await page.input_value("#loginPassword")
            print(f"Initial inputs: username='{u_val}', password='{p_val}'")

            # Click Coach fill button
            print("Clicking Coach fill button #btnFillCoach...")
            await page.click("#btnFillCoach")
            await page.wait_for_timeout(500)

            u_val_after = await page.input_value("#loginEmail")
            p_val_after = await page.input_value("#loginPassword")
            print(f"After Coach Doldur click: username='{u_val_after}', password='{p_val_after}'")

            # Click Login button
            print("Clicking Submit button #loginSubmitBtn...")
            await page.click("#loginSubmitBtn")
            await page.wait_for_timeout(1500)

            # Check URL and appContainer visibility
            current_url = page.url
            app_hidden = await page.eval_on_selector("#appContainer", "el => el.classList.contains('hidden')")
            login_hidden = await page.eval_on_selector("#loginScreen", "el => el.classList.contains('hidden')")
            print(f"After submit: URL='{current_url}', appContainer hidden={app_hidden}, loginScreen hidden={login_hidden}")

            print("\nCaptured Browser Console Logs:")
            for log in console_logs:
                print(log)

            await browser.close()
    except Exception as e:
        print("Playwright exception:", e)

if __name__ == '__main__':
    asyncio.run(main())
