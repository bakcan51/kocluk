import sys
import os
import unittest

sys.path.insert(0, os.path.abspath('backend'))
from app import app, get_db

class ComprehensiveApiDebugAuditTest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

        # Coach login
        res_c = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        self.assertEqual(res_c.status_code, 200)
        self.coach_token = res_c.get_json()['token']
        self.coach_headers = {'Authorization': f'Bearer {self.coach_token}'}

        # Student login
        res_s = self.client.post('/api/auth/login', json={'username': 'burak.akcan', 'password': 'ogrenci123'})
        self.assertEqual(res_s.status_code, 200)
        self.student_token = res_s.get_json()['token']
        self.student_headers = {'Authorization': f'Bearer {self.student_token}'}

    def test_01_api_inventory_and_content_type(self):
        endpoints = [
            ('/api/students', 'GET', self.coach_headers),
            ('/api/weekly-program?student_id=1&week_start=2026-08-10', 'GET', self.coach_headers),
            ('/api/odevler?student_id=1', 'GET', self.coach_headers),
            ('/api/kaynaklar', 'GET', self.coach_headers),
            ('/api/notifications', 'GET', self.coach_headers),
            ('/api/mesajlar/unread-summary', 'GET', self.coach_headers),
            ('/api/kitaplar?student_id=1', 'GET', self.coach_headers),
        ]
        for url, method, hdrs in endpoints:
            if method == 'GET':
                res = self.client.get(url, headers=hdrs)
            self.assertEqual(res.status_code, 200, f"Endpoint {url} failed with {res.status_code}")
            self.assertIn('application/json', res.content_type, f"Endpoint {url} returned non-JSON content-type: {res.content_type}")

    def test_02_ai_coach_mert_demir_boğazici_sayısal(self):
        # Mert Demir student_id = 3 (YKS SAYISAL)
        res = self.client.post('/api/ai/analyze-student', json={'student_id': 3}, headers=self.coach_headers)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['student_id'], 3)
        self.assertIn('Mert Demir', data['student_name'])
        self.assertEqual(data['exam_system'], 'YKS')
        self.assertEqual(data['track'], 'SAYISAL')
        self.assertIn('topic_risks', data)
        self.assertIn('analysisDataQuality', data)

    def test_03_ai_coach_student_zero_exams_handling(self):
        # Student 11 (Ayşe Demir - 0 exams)
        res = self.client.post('/api/ai/analyze-student', json={'student_id': 11}, headers=self.coach_headers)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['valid_exam_count'], 0)
        self.assertIn('Ayşe Demir', data['student_name'])
        self.assertIn('geçerli deneme sınavı verisi bulunmamaktadır', data['summary'])

    def test_04_students_risk_list_endpoint(self):
        res = self.client.get('/api/students', headers=self.coach_headers)
        self.assertEqual(res.status_code, 200)
        students = res.get_json().get('students', [])
        self.assertGreater(len(students), 0)
        for s in students:
            self.assertIn('id', s)
            self.assertIn('name', s)

    def test_05_weekly_program_isolation_and_structure(self):
        res = self.client.get('/api/weekly-program?student_id=3&week_start=2026-08-10', headers=self.coach_headers)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['student']['id'], 3)
        self.assertIn('items', data)

    def test_06_rbac_and_student_isolation(self):
        # Student login should not access /api/admin/*
        res_admin = self.client.get('/api/admin/users', headers=self.student_headers)
        self.assertEqual(res_admin.status_code, 403)

    def test_07_data_preservation_row_count(self):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM students")
        st_cnt = cursor.fetchone()[0]
        self.assertGreaterEqual(st_cnt, 17)

        cursor.execute("SELECT COUNT(*) FROM mock_exams")
        exam_cnt = cursor.fetchone()[0]
        self.assertGreaterEqual(exam_cnt, 80)
        conn.close()

if __name__ == '__main__':
    unittest.main()
