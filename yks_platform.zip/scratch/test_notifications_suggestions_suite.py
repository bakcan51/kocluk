import sys
import os
import json

sys.path.insert(0, os.path.abspath('backend'))

from backend.app import app
from backend.database import get_db

def run_notifications_suggestions_suite():
    print("==================================================")
    print("🚀 RUNNING 10 AUTOMATED TEST SCENARIOS FOR BİLDİRİMLER & KAYNAK ÖNERİLERİ")
    print("==================================================")

    client = app.test_client()

    # Logins
    res_coach = client.post('/api/login', json={'username': 'ummu.akcan', 'password': 'password123'})
    assert res_coach.status_code == 200
    coach_token = res_coach.get_json()['token']

    res_admin = client.post('/api/login', json={'username': 'admin', 'password': 'password123'})
    assert res_admin.status_code == 200
    admin_token = res_admin.get_json()['token']

    coach_headers = {'Authorization': f'Bearer {coach_token}'}
    admin_headers = {'Authorization': f'Bearer {admin_token}'}

    # TEST 1: Coach adds new resource to personal pool & suggests to Genel Havuz
    res1 = client.post('/api/kaynaklar', headers=coach_headers, json={
        'title': '3D TYT Fizik Soru Bankası Test-A',
        'name': '3D TYT Fizik Soru Bankası Test-A',
        'publisher': '3D Yayınları',
        'subject_id': 3,
        'exam_system': 'YKS',
        'exam_type': 'TYT',
        'field': 'SAYISAL',
        'resource_type': 'Soru Bankası',
        'total_questions': 850
    })
    assert res1.status_code == 200, f"Test 1 failed: {res1.get_data(as_text=True)}"
    data1 = res1.get_json()
    c_res_id_1 = data1.get('resource_id') or data1.get('id')
    print("✅ TEST 1 PASSED: Coach added resource and generated Admin recommendation.")

    # TEST 2: Admin clicks Kaynaklar category filter tab
    res2 = client.get('/api/notifications?category=RESOURCE', headers=admin_headers)
    assert res2.status_code == 200
    data2 = res2.get_json()
    notifs2 = data2.get('notifications', [])
    for n in notifs2:
        assert n['type'].startswith('RESOURCE_'), f"Unexpected non-resource notification: {n['type']}"
    print(f"✅ TEST 2 PASSED: Category filter 'RESOURCE' returned {len(notifs2)} resource notifications.")

    # TEST 3: Admin retrieves resource suggestions and inspects metadata
    res3 = client.get('/api/admin/resource-suggestions', headers=admin_headers)
    assert res3.status_code == 200
    data3 = res3.get_json()
    sugs3 = data3.get('suggestions', [])
    target_sug_1 = next((s for s in sugs3 if s['coach_resource_id'] == c_res_id_1), None)
    assert target_sug_1 is not None, "Target suggestion not found!"
    assert target_sug_1['status'] == 'BEKLİYOR'
    assert target_sug_1['resource_title'] == '3D TYT Fizik Soru Bankası Test-A'
    sug_id_1 = target_sug_1['id']
    print(f"✅ TEST 3 PASSED: Suggestion detail metadata verified for suggestion #{sug_id_1}.")

    # TEST 4: Admin approves recommendation
    res4 = client.post(f'/api/admin/resource-suggestions/{sug_id_1}/respond', headers=admin_headers, json={'action': 'APPROVE'})
    assert res4.status_code == 200, f"Test 4 failed: {res4.get_data(as_text=True)}"
    data4 = res4.get_json()
    assert data4['status'] == 'ONAYLANDI'
    print("✅ TEST 4 PASSED: Admin approved recommendation -> Added to Genel Havuz.")

    # TEST 5: Attempt duplicate approval on same suggestion (Idempotency Guard)
    res5 = client.post(f'/api/admin/resource-suggestions/{sug_id_1}/respond', headers=admin_headers, json={'action': 'APPROVE'})
    assert res5.status_code == 400
    data5 = res5.get_json()
    assert 'daha önce işlenmiş' in data5['error']
    print("✅ TEST 5 PASSED: Idempotency guard blocked duplicate approval attempts.")

    # TEST 6: Check Coach feed for approval notification
    res6 = client.get('/api/notifications', headers=coach_headers)
    assert res6.status_code == 200
    data6 = res6.get_json()
    coach_notifs = data6.get('notifications', [])
    appr_notif = next((n for n in coach_notifs if 'onaylandı' in n['message']), None)
    assert appr_notif is not None, "Coach approval notification not found!"
    print(f"✅ TEST 6 PASSED: Coach received approval notification: '{appr_notif['message']}'")

    # TEST 7: Coach adds 2nd resource -> Pending count increases by 1
    res7_before = client.get('/api/admin/resource-suggestions', headers=admin_headers).get_json()['suggestions']
    pending_before = len([s for s in res7_before if s['status'] == 'BEKLİYOR'])

    res7 = client.post('/api/kaynaklar', headers=coach_headers, json={
        'title': 'Esen AYT Biyoloji Soru Bankası Test-B',
        'name': 'Esen AYT Biyoloji Soru Bankası Test-B',
        'publisher': 'Esen Yayınları',
        'subject_id': 4,
        'exam_system': 'YKS',
        'exam_type': 'AYT',
        'field': 'SAYISAL',
        'resource_type': 'Soru Bankası',
        'total_questions': 620
    })
    assert res7.status_code == 200
    c_res_id_2 = res7.get_json().get('resource_id') or res7.get_json().get('id')

    res7_after = client.get('/api/admin/resource-suggestions', headers=admin_headers).get_json()['suggestions']
    pending_after = len([s for s in res7_after if s['status'] == 'BEKLİYOR'])
    assert pending_after == pending_before + 1
    target_sug_2 = next((s for s in res7_after if s['coach_resource_id'] == c_res_id_2), None)
    sug_id_2 = target_sug_2['id']
    print(f"✅ TEST 7 PASSED: Pending count increased by 1 (Now {pending_after} pending).")

    # TEST 8: Admin rejects 2nd recommendation with rejection reason
    rej_reason = "Benzer AYT Biyoloji kaynağı Genel Havuz'da zaten mevcut."
    res8 = client.post(f'/api/admin/resource-suggestions/{sug_id_2}/respond', headers=admin_headers, json={
        'action': 'REJECT',
        'rejection_reason': rej_reason
    })
    assert res8.status_code == 200
    data8 = res8.get_json()
    assert data8['status'] == 'REDDEDİLDİ'

    # Check coach feed for rejection notification
    res8_coach = client.get('/api/notifications', headers=coach_headers).get_json()['notifications']
    rej_notif = next((n for n in res8_coach if 'eklenmedi' in n['message']), None)
    assert rej_notif is not None
    assert rej_reason in rej_notif['message']
    print(f"✅ TEST 8 PASSED: Rejection recorded with reason and Coach notified: '{rej_notif['message']}'")

    # TEST 9: Read notification -> Unread counter decreases
    res9_unread_before = client.get('/api/notifications?unread_only=true', headers=coach_headers).get_json()['unread_count']
    if coach_notifs:
        target_notif_id = coach_notifs[0]['id']
        res9_read = client.post(f'/api/notifications/{target_notif_id}/read', headers=coach_headers)
        assert res9_read.status_code == 200
        res9_unread_after = client.get('/api/notifications?unread_only=true', headers=coach_headers).get_json()['unread_count']
        assert res9_unread_after < res9_unread_before or res9_unread_before == 0
        print("✅ TEST 9 PASSED: Notification read status updated and unread counter decreased.")

    # TEST 10: State Persistence
    res10_sugs = client.get('/api/admin/resource-suggestions', headers=admin_headers).get_json()['suggestions']
    sug_1_check = next((s for s in res10_sugs if s['id'] == sug_id_1), None)
    sug_2_check = next((s for s in res10_sugs if s['id'] == sug_id_2), None)
    assert sug_1_check['status'] == 'ONAYLANDI'
    assert sug_2_check['status'] == 'REDDEDİLDİ'
    assert sug_2_check['rejection_reason'] == rej_reason
    print("✅ TEST 10 PASSED: All suggestion statuses, rejection reasons, and notification states persisted cleanly.")

    print("==================================================")
    print("🎉 ALL 10 SCENARIOS PASSED 100%!")
    print("==================================================")

if __name__ == "__main__":
    run_notifications_suggestions_suite()
