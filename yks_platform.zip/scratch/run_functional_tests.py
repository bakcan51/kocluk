import os
import sys
import json
import traceback

# Add backend directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../backend')))

from app import app
from database import get_db

def run_tests():
    client = app.test_client()
    results = []

    def record_result(view_flow, steps, expected, actual, severity, notes_err, status_pass=True):
        results.append({
            "page_flow": view_flow,
            "steps": steps,
            "expected": expected,
            "actual": actual,
            "severity": severity,
            "notes": notes_err,
            "pass": status_pass
        })

    def get_auth_headers(user_id):
        return {"Authorization": f"Bearer {user_id}", "Content-Type": "application/json"}

    print("--- STARTING COMPREHENSIVE E2E FUNCTIONAL API & ROLE ISOLATION AUDIT ---")

    # Helper DB lookup
    conn = get_db()
    st4_row = conn.execute("SELECT id FROM students WHERE user_id = 4").fetchone()
    st5_row = conn.execute("SELECT id FROM students WHERE user_id = 5").fetchone()
    conn.close()

    st4_id = st4_row['id'] if st4_row else 1
    st5_id = st5_row['id'] if st5_row else 2

    # 1. AUTHENTICATION & LOGIN WORKFLOW
    try:
        # 1.1 Invalid credentials
        res = client.post('/api/auth/login', json={"username": "invalid_user", "password": "wrongpassword"})
        if res.status_code in [400, 401] and not (res.is_json and res.get_json().get('success', False)):
            record_result("Giriş Ekranı", "Hatalı kullanıcı adı/şifre ile POST /api/auth/login", "401/400 Hata ve success:false dönmeli", f"Status: {res.status_code}, Msg: {res.get_json().get('message') if res.is_json else res.text}", "Kritik", "Yok", True)
        else:
            record_result("Giriş Ekranı", "Hatalı kullanıcı adı/şifre ile POST /api/auth/login", "401 Hata dönmeli", f"Status: {res.status_code}", "Kritik", f"Unexpected response: {res.text}", False)

        # 1.2 Empty fields
        res_empty = client.post('/api/auth/login', json={"username": "", "password": ""})
        record_result("Giriş Ekranı (Form Val)", "Boş kullanıcı adı/şifre ile POST /api/auth/login", "400/401 Hata dönmeli", f"Status: {res_empty.status_code}, Body: {res_empty.text}", "Yüksek", "Yok" if res_empty.status_code in [400, 401] else "Boş veri kabul edilmemeli", res_empty.status_code in [400, 401])

        # 1.3 Coach Login
        res_coach = client.post('/api/auth/login', json={"username": "ummu.akcan", "password": "password123"})
        coach_data = res_coach.get_json() if res_coach.is_json else {}
        if res_coach.status_code == 200 and coach_data.get('success') and coach_data.get('user', {}).get('role') == 'COACH':
            record_result("Giriş Ekranı (Koç)", "Koç bilgileri ile POST /api/auth/login (ummu.akcan)", "HTTP 200, success:true, role:COACH dönmeli", f"Status: {res_coach.status_code}, User: {coach_data['user']['name']} ({coach_data['user']['role']})", "Kritik", "Yok", True)
        else:
            record_result("Giriş Ekranı (Koç)", "Koç bilgileri ile POST /api/auth/login", "HTTP 200 ve role:COACH dönmeli", f"Status: {res_coach.status_code}, Data: {res_coach.text}", "Kritik", "Giriş başarısız", False)

        # 1.4 Student Login
        res_student = client.post('/api/auth/login', json={"username": "burak.akcan", "password": "ogrenci123"})
        student_data = res_student.get_json() if res_student.is_json else {}
        if res_student.status_code == 200 and student_data.get('success') and student_data.get('user', {}).get('role') == 'STUDENT':
            record_result("Giriş Ekranı (Öğrenci)", "Öğrenci bilgileri ile POST /api/auth/login (burak.akcan)", "HTTP 200, success:true, role:STUDENT dönmeli", f"Status: {res_student.status_code}, User: {student_data['user']['name']} ({student_data['user']['role']})", "Kritik", "Yok", True)
        else:
            record_result("Giriş Ekranı (Öğrenci)", "Öğrenci bilgileri ile POST /api/auth/login", "HTTP 200 ve role:STUDENT dönmeli", f"Status: {res_student.status_code}, Data: {res_student.text}", "Kritik", "Giriş başarısız", False)

        # 1.5 Admin Login
        res_admin = client.post('/api/auth/login', json={"username": "admin", "password": "password123"})
        admin_data = res_admin.get_json() if res_admin.is_json else {}
        if res_admin.status_code == 200 and admin_data.get('success') and admin_data.get('user', {}).get('role') == 'ADMIN':
            record_result("Giriş Ekranı (Admin)", "Admin bilgileri ile POST /api/auth/login (admin)", "HTTP 200, success:true, role:ADMIN dönmeli", f"Status: {res_admin.status_code}, User: {admin_data['user']['name']} ({admin_data['user']['role']})", "Kritik", "Yok", True)
        else:
            record_result("Giriş Ekranı (Admin)", "Admin bilgileri ile POST /api/auth/login", "HTTP 200 ve role:ADMIN dönmeli", f"Status: {res_admin.status_code}, Data: {res_admin.text}", "Kritik", "Giriş başarısız", False)

    except Exception as e:
        record_result("Giriş Ekranı", "Giriş testleri çalıştırılıyor", "İstisna oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 2. DASHBOARD VIEW AUDIT
    try:
        # Coach Dashboard (User ID = 2)
        res = client.get('/api/koc/dashboard', headers=get_auth_headers(2))
        if res.status_code == 200:
            record_result("Koç Paneli (Dashboard)", "GET /api/koc/dashboard (Koç token)", "HTTP 200 & koç özet istatistikleri", f"Status 200, Keys: {list(res.get_json().keys()) if res.is_json else 'ok'}", "Kritik", "Yok", True)
        else:
            record_result("Koç Paneli (Dashboard)", "GET /api/koc/dashboard", "HTTP 200 dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

        # Student Dashboard (User ID = 4)
        res_st_dash = client.get('/api/student/dashboard', headers=get_auth_headers(4))
        if res_st_dash.status_code == 200:
            record_result("Öğrenci Paneli (Dashboard)", "GET /api/student/dashboard (Öğrenci token)", "HTTP 200 & öğrenciye özel metrikler", f"Status 200, Keys: {list(res_st_dash.get_json().keys()) if res_st_dash.is_json else 'ok'}", "Kritik", "Yok", True)
        else:
            record_result("Öğrenci Paneli (Dashboard)", "GET /api/student/dashboard", "HTTP 200 dönmeli", f"Status {res_st_dash.status_code}", "Kritik", res_st_dash.text, False)

        # Admin Dashboard (User ID = 1)
        res_adm_dash = client.get('/api/admin/dashboard', headers=get_auth_headers(1))
        if res_adm_dash.status_code == 200:
            record_result("Admin Paneli (Dashboard)", "GET /api/admin/dashboard (Admin token)", "HTTP 200 & sistem metrikleri", f"Status 200, Keys: {list(res_adm_dash.get_json().keys()) if res_adm_dash.is_json else 'ok'}", "Yüksek", "Yok", True)
        else:
            record_result("Admin Paneli (Dashboard)", "GET /api/admin/dashboard", "HTTP 200 dönmeli", f"Status {res_adm_dash.status_code}", "Yüksek", res_adm_dash.text, False)

    except Exception as e:
        record_result("Dashboard", "Dashboard endpoint testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 3. ÖĞRENCİLERİM & RİSK VIEW AUDIT
    try:
        # Coach (ID 2)
        res = client.get('/api/students', headers=get_auth_headers(2))
        st_list = res.get_json() if res.is_json else []
        if res.status_code == 200 and isinstance(st_list, list):
            record_result("Öğrencilerim & Risk", "GET /api/students (Koç token)", "HTTP 200 & atanmış öğrenci listesi", f"Status 200, Toplam {len(st_list)} öğrenci", "Kritik", "Yok", True)
            if len(st_list) > 0:
                first_st_id = st_list[0]['id']
                res_det = client.get(f'/api/students/{first_st_id}', headers=get_auth_headers(2))
                if res_det.status_code == 200:
                    record_result("Öğrenci Detay", f"GET /api/students/{first_st_id} (Koç token)", "HTTP 200 & öğrenci profili ve risk detayları", f"Status 200, Öğrenci ID: {first_st_id}", "Kritik", "Yok", True)
                else:
                    record_result("Öğrenci Detay", f"GET /api/students/{first_st_id}", "HTTP 200 dönmeli", f"Status {res_det.status_code}", "Kritik", res_det.text, False)
        else:
            record_result("Öğrencilerim & Risk", "GET /api/students", "HTTP 200 & liste dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

    except Exception as e:
        record_result("Öğrencilerim & Risk", "Öğrenci listeleme/detay testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 4. HAFTALIK PROGRAM VIEW AUDIT & CRUD
    try:
        # GET program for st4
        res = client.get(f'/api/haftalik-program?student_id={st4_id}', headers=get_auth_headers(4))
        if res.status_code == 200:
            record_result("Haftalık Program", f"GET /api/haftalik-program?student_id={st4_id} (Öğrenci token)", "HTTP 200 & haftalık ders programı", f"Status 200", "Kritik", "Yok", True)
        else:
            record_result("Haftalık Program", "GET /api/haftalik-program", "HTTP 200 dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

        # POST program (Create by Coach)
        prog_payload = {
            "student_id": st4_id,
            "day_of_week": "Pazartesi",
            "start_time": "09:00",
            "end_time": "10:00",
            "subject": "Matematik 🚀 Test",
            "topic": "Türev ve İntegral ÇĞİÖŞÜçğiöşü",
            "target_question_count": 50,
            "notes": "<script>alert('xss')</script> Test Not"
        }
        res_post = client.post('/api/haftalik-program', json=prog_payload, headers=get_auth_headers(2))
        if res_post.status_code in [200, 201]:
            record_result("Haftalık Program (Ekleme)", "POST /api/haftalik-program (XSS, Türkçe Karakter, Emoji)", "HTTP 200/201 & Program ögesi eklendi", f"Status {res_post.status_code}", "Yüksek", "Yok", True)
        else:
            record_result("Haftalık Program (Ekleme)", "POST /api/haftalik-program", "HTTP 200/201 dönmeli", f"Status {res_post.status_code}", "Yüksek", res_post.text, False)

    except Exception as e:
        record_result("Haftalık Program", "Program CRUD testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 5. ÖDEV YÖNETİMİ AUDIT & CRUD
    try:
        # GET odevler
        res = client.get(f'/api/odevler?student_id={st4_id}', headers=get_auth_headers(4))
        if res.status_code == 200:
            record_result("Ödev Yönetimi", f"GET /api/odevler?student_id={st4_id} (Öğrenci token)", "HTTP 200 & ödev listesi", f"Status 200", "Kritik", "Yok", True)
        else:
            record_result("Ödev Yönetimi", "GET /api/odevler", "HTTP 200 dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

        # POST odev (Create by Coach 2)
        odev_payload = {
            "student_id": st4_id,
            "title": "Fizik Optik Testi 🎯",
            "description": "Aynalar ve Mercekler ÇĞİÖŞÜ",
            "due_date": "2026-08-30",
            "subject": "Fizik",
            "target_question_count": 40
        }
        res_post = client.post('/api/odevler', json=odev_payload, headers=get_auth_headers(2))
        odev_res_json = res_post.get_json() if res_post.is_json else {}
        created_odev_id = odev_res_json.get('id') or odev_res_json.get('assignment_id')
        if res_post.status_code in [200, 201]:
            record_result("Ödev Yönetimi (Ekleme)", "POST /api/odevler (Koç tarafından ödev atama)", "HTTP 200/201 & Ödev ID oluşturuldu", f"Status {res_post.status_code}, Res: {odev_res_json}", "Kritik", "Yok", True)
        else:
            record_result("Ödev Yönetimi (Ekleme)", "POST /api/odevler", "HTTP 200/201 dönmeli", f"Status {res_post.status_code}", "Kritik", res_post.text, False)

        # PUT odev (Update by Student st4)
        if created_odev_id:
            res_put = client.put('/api/odevler', json={"id": created_odev_id, "status": "TAMAMLANTI", "notes": "Tamamlandı notu"}, headers=get_auth_headers(4))
            record_result("Ödev Yönetimi (Güncelleme)", f"PUT /api/odevler (ID={created_odev_id})", "HTTP 200 & Durum güncellendi", f"Status {res_put.status_code}", "Yüksek", "Yok" if res_put.status_code == 200 else res_put.text, res_put.status_code == 200)

            # DELETE odev (Delete by Coach 2)
            res_del = client.delete(f'/api/odevler?id={created_odev_id}', headers=get_auth_headers(2))
            record_result("Ödev Yönetimi (Silme)", f"DELETE /api/odevler?id={created_odev_id}", "HTTP 200 & Ödev silindi", f"Status {res_del.status_code}", "Yüksek", "Yok" if res_del.status_code == 200 else res_del.text, res_del.status_code == 200)

    except Exception as e:
        record_result("Ödev Yönetimi", "Ödev CRUD testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 6. MÜFREDAT & KAYNAK TAKİBİ AUDIT
    try:
        res = client.get(f'/api/mufredat?student_id={st4_id}', headers=get_auth_headers(4))
        if res.status_code == 200:
            record_result("Müfredat & Kaynak Takibi", f"GET /api/mufredat?student_id={st4_id} (Öğrenci token)", "HTTP 200 & Müfredat ders/konu ağacı", f"Status 200", "Kritik", "Yok", True)
        else:
            record_result("Müfredat & Kaynak Takibi", "GET /api/mufredat", "HTTP 200 dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

        # Update topic status
        res_upd = client.post('/api/mufredat/konu-durum-guncelle', json={"student_id": st4_id, "topic_id": 1, "status": "TAMAMLANDI"}, headers=get_auth_headers(4))
        record_result("Müfredat (Konu Durumu)", "POST /api/mufredat/konu-durum-guncelle", "HTTP 200 & Durum 'TAMAMLANDI' güncellendi", f"Status {res_upd.status_code}", "Yüksek", "Yok" if res_upd.status_code == 200 else res_upd.text, res_upd.status_code == 200)

    except Exception as e:
        record_result("Müfredat & Kaynak Takibi", "Müfredat testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 7. KAYNAK HAVUZUM AUDIT & CRUD
    try:
        res = client.get('/api/kaynak-havuzu', headers=get_auth_headers(2))
        if res.status_code == 200:
            record_result("Kaynak Havuzum", "GET /api/kaynak-havuzu (Koç token)", "HTTP 200 & Kaynak kütüphanesi", f"Status 200", "Kritik", "Yok", True)
        else:
            record_result("Kaynak Havuzum", "GET /api/kaynak-havuzu", "HTTP 200 dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

        # Create new resource
        new_res_payload = {
            "name": "3D TYT Matematik Soru Bankası ⚡",
            "publisher": "3D Yayınları",
            "subject": "Matematik",
            "difficulty": "Zor",
            "type": "Soru Bankası"
        }
        res_create = client.post('/api/kaynak-havuzu', json=new_res_payload, headers=get_auth_headers(2))
        res_create_json = res_create.get_json() if res_create.is_json else {}
        created_res_id = res_create_json.get('id') or res_create_json.get('resource_id')
        if res_create.status_code in [200, 201]:
            record_result("Kaynak Havuzum (Ekleme)", "POST /api/kaynak-havuzu (Yeni Kaynak)", "HTTP 200/201 & Kaynak eklendi", f"Status {res_create.status_code}, ID: {created_res_id}", "Yüksek", "Yok", True)
        else:
            record_result("Kaynak Havuzum (Ekleme)", "POST /api/kaynak-havuzu", "HTTP 200/201 dönmeli", f"Status {res_create.status_code}", "Yüksek", res_create.text, False)

        if created_res_id:
            res_put = client.put(f'/api/kaynak-havuzu/{created_res_id}', json={"name": "3D TYT Matematik (Güncel)", "difficulty": "Orta"}, headers=get_auth_headers(2))
            record_result("Kaynak Havuzum (Düzenleme)", f"PUT /api/kaynak-havuzu/{created_res_id}", "HTTP 200 & Bilgiler güncellendi", f"Status {res_put.status_code}", "Orta", "Yok" if res_put.status_code == 200 else res_put.text, res_put.status_code == 200)

            res_del = client.delete(f'/api/kaynak-havuzu/{created_res_id}', headers=get_auth_headers(2))
            record_result("Kaynak Havuzum (Silme)", f"DELETE /api/kaynak-havuzu/{created_res_id}", "HTTP 200 & Kaynak silindi", f"Status {res_del.status_code}", "Orta", "Yok" if res_del.status_code == 200 else res_del.text, res_del.status_code == 200)

    except Exception as e:
        record_result("Kaynak Havuzum", "Kaynak Havuzu CRUD testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 8. DENEME & KONU ANALİZİ AUDIT & CRUD
    try:
        res = client.get(f'/api/deneme?student_id={st4_id}', headers=get_auth_headers(4))
        if res.status_code == 200:
            record_result("Deneme & Konu Analizi", f"GET /api/deneme?student_id={st4_id} (Öğrenci token)", "HTTP 200 & Deneme sonuçları", f"Status 200", "Kritik", "Yok", True)
        else:
            record_result("Deneme & Konu Analizi", "GET /api/deneme", "HTTP 200 dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

        # POST Deneme (Create)
        deneme_payload = {
            "student_id": st4_id,
            "title": "3D TYT Genel Deneme #1 📊",
            "exam_type": "TYT",
            "exam_date": "2026-08-15",
            "publisher": "3D Yayınları",
            "tyt_turkce_d": 35, "tyt_turkce_y": 5,
            "tyt_mat_d": 32, "tyt_mat_y": 3,
            "tyt_sosyal_d": 16, "tyt_sosyal_y": 4,
            "tyt_fen_d": 15, "tyt_fen_y": 3
        }
        res_post = client.post('/api/deneme', json=deneme_payload, headers=get_auth_headers(4))
        res_post_json = res_post.get_json() if res_post.is_json else {}
        created_deneme_id = res_post_json.get('id') or res_post_json.get('attempt_id')
        if res_post.status_code in [200, 201]:
            record_result("Deneme (Ekleme & Net Hesabı)", "POST /api/deneme (Net ve Puan hesabı)", "HTTP 200/201 & Otomatik Net/Puan hesabı", f"Status {res_post.status_code}", "Kritik", "Yok", True)
        else:
            record_result("Deneme (Ekleme & Net Hesabı)", "POST /api/deneme", "HTTP 200/201 dönmeli", f"Status {res_post.status_code}", "Kritik", res_post.text, False)

        # Compare Denemeler
        res_comp = client.get(f'/api/deneme/compare?student_id={st4_id}', headers=get_auth_headers(4))
        record_result("Deneme Karşılaştırma", f"GET /api/deneme/compare?student_id={st4_id}", "HTTP 200 & Gelişim analizi verileri", f"Status {res_comp.status_code}", "Yüksek", "Yok" if res_comp.status_code == 200 else res_comp.text, res_comp.status_code == 200)

        if created_deneme_id:
            res_del = client.delete(f'/api/deneme/{created_deneme_id}', headers=get_auth_headers(4))
            record_result("Deneme (Silme)", f"DELETE /api/deneme/{created_deneme_id}", "HTTP 200 & Deneme silindi", f"Status {res_del.status_code}", "Orta", "Yok" if res_del.status_code == 200 else res_del.text, res_del.status_code == 200)

    except Exception as e:
        record_result("Deneme & Konu Analizi", "Deneme testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 9. AKADEMİK RAPORLAR AUDIT
    try:
        res = client.get(f'/api/raporlar?student_id={st4_id}', headers=get_auth_headers(2))
        if res.status_code == 200:
            record_result("Akademik Raporlar", f"GET /api/raporlar?student_id={st4_id} (Koç token)", "HTTP 200 & Performans raporu", f"Status 200", "Kritik", "Yok", True)
        else:
            record_result("Akademik Raporlar", "GET /api/raporlar", "HTTP 200 dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

    except Exception as e:
        record_result("Akademik Raporlar", "Rapor testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 10. YKS PUAN SİMÜLATÖRÜ AUDIT
    try:
        sim_payload = {
            "tyt_turkce_net": 33.75,
            "tyt_sosyal_net": 15.0,
            "tyt_mat_net": 31.25,
            "tyt_fen_net": 14.25,
            "ayt_mat_net": 28.0,
            "ayt_fizik_net": 11.5,
            "ayt_kimya_net": 10.0,
            "ayt_biyoloji_net": 9.5,
            "obp": 92.5
        }
        res = client.post('/api/simulasyon/puan-hesapla', json=sim_payload, headers=get_auth_headers(4))
        if res.status_code == 200:
            calc_data = res.get_json() if res.is_json else {}
            record_result("YKS Puan Simülatörü", "POST /api/simulasyon/puan-hesapla (Geçerli Net/OBP)", "HTTP 200 & Hesaplanan puanlar ve sıralama", f"Status 200, Puanlar: {calc_data.get('scores') or calc_data}", "Kritik", "Yok", True)
        else:
            record_result("YKS Puan Simülatörü", "POST /api/simulasyon/puan-hesapla", "HTTP 200 dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

    except Exception as e:
        record_result("YKS Puan Simülatörü", "Puan simülatör testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 11. KİTAP OKUMA TAKİBİ AUDIT & CRUD
    try:
        res = client.get(f'/api/kitaplar?student_id={st4_id}', headers=get_auth_headers(4))
        if res.status_code == 200:
            record_result("Kitap Okuma Takibi", f"GET /api/kitaplar?student_id={st4_id}", "HTTP 200 & Kitap listesi", f"Status 200", "Kritik", "Yok", True)
        else:
            record_result("Kitap Okuma Takibi", "GET /api/kitaplar", "HTTP 200 dönmeli", f"Status {res.status_code}", "Kritik", res.text, False)

        book_payload = {
            "student_id": st4_id,
            "title": "Nutuk 📖 (ÇĞİÖŞÜ)",
            "author": "Mustafa Kemal Atatürk",
            "page_count": 600,
            "read_pages": 150,
            "status": "OKUNUYOR"
        }
        res_post = client.post('/api/kitaplar', json=book_payload, headers=get_auth_headers(4))
        record_result("Kitap Okuma (Ekleme)", "POST /api/kitaplar (Yeni Kitap)", "HTTP 200/201 & Kitap eklendi", f"Status {res_post.status_code}", "Yüksek", "Yok" if res_post.status_code in [200, 201] else res_post.text, res_post.status_code in [200, 201])

    except Exception as e:
        record_result("Kitap Okuma Takibi", "Kitap okuma testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 12. MESAJLAŞMA AUDIT & CRUD
    try:
        res_contacts = client.get('/api/mesajlar/contacts', headers=get_auth_headers(4))
        record_result("Mesajlaşma (Kişiler)", "GET /api/mesajlar/contacts", "HTTP 200 & Kişi listesi", f"Status {res_contacts.status_code}", "Kritik", "Yok" if res_contacts.status_code == 200 else res_contacts.text, res_contacts.status_code == 200)

        res_msg = client.get('/api/mesajlar', headers=get_auth_headers(4))
        record_result("Mesajlaşma (Mesaj Geçmişi)", "GET /api/mesajlar", "HTTP 200 & Mesajlar", f"Status {res_msg.status_code}", "Kritik", "Yok" if res_msg.status_code == 200 else res_msg.text, res_msg.status_code == 200)

        msg_payload = {
            "receiver_id": 2, # send to coach
            "content": "Hocam merhaba, bu bir test mesajıdır! 💬 ÇĞİÖŞÜçğiöşü <script>console.log(1)</script>"
        }
        res_send = client.post('/api/mesajlar', json=msg_payload, headers=get_auth_headers(4))
        record_result("Mesajlaşma (Mesaj Gönderme)", "POST /api/mesajlar (Mesaj iletimi, XSS, Emoji, Türkçe)", "HTTP 200/201 & Mesaj iletildi", f"Status {res_send.status_code}", "Kritik", "Yok" if res_send.status_code in [200, 201] else res_send.text, res_send.status_code in [200, 201])

    except Exception as e:
        record_result("Mesajlaşma", "Mesajlaşma testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 13. ÇALIŞMA ZAMANLAYICISI & SORU TAKİBİ AUDIT
    try:
        timer_payload = {
            "student_id": st4_id,
            "subject": "Matematik",
            "duration_minutes": 45,
            "question_count": 30,
            "completed": True,
            "session_type": "POMODORO"
        }
        res_timer = client.post('/api/timer', json=timer_payload, headers=get_auth_headers(4))
        record_result("Çalışma Zamanlayıcısı", "POST /api/timer (Çalışma Seansı)", "HTTP 200/201 & Seans kaydedildi", f"Status {res_timer.status_code}", "Yüksek", "Yok" if res_timer.status_code in [200, 201] else res_timer.text, res_timer.status_code in [200, 201])

        res_soru_get = client.get(f'/api/soru-takibi?student_id={st4_id}', headers=get_auth_headers(4))
        record_result("Soru Takibi (Listeleme)", f"GET /api/soru-takibi?student_id={st4_id}", "HTTP 200 & Çözülen soru sayıları", f"Status {res_soru_get.status_code}", "Kritik", "Yok" if res_soru_get.status_code == 200 else res_soru_get.text, res_soru_get.status_code == 200)

        soru_payload = {
            "student_id": st4_id,
            "subject": "Fizik",
            "topic": "Elektrik",
            "correct_count": 20,
            "wrong_count": 2,
            "empty_count": 3
        }
        res_soru_post = client.post('/api/soru-takibi', json=soru_payload, headers=get_auth_headers(4))
        record_result("Soru Takibi (Ekleme)", "POST /api/soru-takibi", "HTTP 200/201 & Soru sayısı eklendi", f"Status {res_soru_post.status_code}", "Yüksek", "Yok" if res_soru_post.status_code in [200, 201] else res_soru_post.text, res_soru_post.status_code in [200, 201])

    except Exception as e:
        record_result("Çalışma Zamanlayıcısı", "Zamanlayıcı testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 14. AI KOÇ ASİSTANI AUDIT
    try:
        ai_payload = {
            "student_id": st4_id,
            "prompt": "Matematik netlerimi artırmak için bu hafta nasıl bir strateji izlemeliyim?"
        }
        res_ai = client.post('/api/ai/analyze-student', json=ai_payload, headers=get_auth_headers(4))
        record_result("AI Koç Asistanı", "POST /api/ai/analyze-student", "HTTP 200 & AI tavsiye yanıtı", f"Status {res_ai.status_code}", "Yüksek", "Yok" if res_ai.status_code == 200 else res_ai.text, res_ai.status_code == 200)

    except Exception as e:
        record_result("AI Koç Asistanı", "AI koç asistanı testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Yüksek", traceback.format_exc(), False)

    # 15. BİLDİRİMLER AUDIT
    try:
        res_notif = client.get('/api/notifications', headers=get_auth_headers(4))
        record_result("Bildirimler", "GET /api/notifications", "HTTP 200 & Bildirim listesi", f"Status {res_notif.status_code}", "Kritik", "Yok" if res_notif.status_code == 200 else res_notif.text, res_notif.status_code == 200)

        res_read_all = client.post('/api/notifications/read-all', headers=get_auth_headers(4))
        record_result("Bildirimler (Tümünü Okundu Yap)", "POST /api/notifications/read-all", "HTTP 200 & Okundu işaretlendi", f"Status {res_read_all.status_code}", "Orta", "Yok" if res_read_all.status_code == 200 else res_read_all.text, res_read_all.status_code == 200)

    except Exception as e:
        record_result("Bildirimler", "Bildirim testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # 16. ROLE ISOLATION & SECURITY AUDIT (CRITICAL)
    try:
        # 16.1 Student 4 trying to view Student 5's detail
        res_isolation = client.get(f'/api/students/{st5_id}', headers=get_auth_headers(4))
        if res_isolation.status_code in [403, 401, 404]:
            record_result("Rol İzolasyonu (Öğrenci Veri Koruma)", f"Öğrenci 4 -> GET /api/students/{st5_id} (Öğrenci 5)", "HTTP 403 Forbidden / Yetkisiz", f"Status {res_isolation.status_code} (Erişim engellendi)", "Kritik", "Yok", True)
        else:
            record_result("Rol İzolasyonu (Öğrenci Veri Koruma)", f"Öğrenci 4 -> GET /api/students/{st5_id}", "HTTP 403 Forbidden olmalı", f"Status {res_isolation.status_code} (GÜVENLİK AÇIĞI!)", "Kritik", f"Öğrenci başka öğrenci verisine ulaştı: {res_isolation.text}", False)

        # 16.2 Student trying to access Coach Dashboard
        res_coach_dash_st = client.get('/api/koc/dashboard', headers=get_auth_headers(4))
        if res_coach_dash_st.status_code in [403, 401]:
            record_result("Rol İzolasyonu (Koç Paneli Erişimi)", "Öğrenci -> GET /api/koc/dashboard", "HTTP 403 Forbidden / Yetkisiz", f"Status {res_coach_dash_st.status_code} (Erişim reddedildi)", "Kritik", "Yok", True)
        else:
            record_result("Rol İzolasyonu (Koç Paneli Erişimi)", "Öğrenci -> GET /api/koc/dashboard", "HTTP 403 Forbidden olmalı", f"Status {res_coach_dash_st.status_code}", "Kritik", f"Erişim engellenmedi", False)

        # 16.3 Student trying to access Admin Users endpoint
        res_admin_users_st = client.get('/api/admin/users', headers=get_auth_headers(4))
        if res_admin_users_st.status_code in [403, 401]:
            record_result("Rol İzolasyonu (Admin Paneli Erişimi)", "Öğrenci -> GET /api/admin/users", "HTTP 403 Forbidden / Yetkisiz", f"Status {res_admin_users_st.status_code} (Erişim reddedildi)", "Kritik", "Yok", True)
        else:
            record_result("Rol İzolasyonu (Admin Paneli Erişimi)", "Öğrenci -> GET /api/admin/users", "HTTP 403 Forbidden olmalı", f"Status {res_admin_users_st.status_code}", "Kritik", f"Erişim engellenmedi", False)

        # 16.4 Coach trying to access Admin Users endpoint
        res_admin_users_coach = client.get('/api/admin/users', headers=get_auth_headers(2))
        if res_admin_users_coach.status_code in [403, 401]:
            record_result("Rol İzolasyonu (Koç -> Admin Paneli Erişimi)", "Koç -> GET /api/admin/users", "HTTP 403 Forbidden / Yetkisiz", f"Status {res_admin_users_coach.status_code} (Erişim reddedildi)", "Kritik", "Yok", True)
        else:
            record_result("Rol İzolasyonu (Koç -> Admin Paneli Erişimi)", "Koç -> GET /api/admin/users", "HTTP 403 Forbidden olmalı", f"Status {res_admin_users_coach.status_code}", "Kritik", f"Erişim engellenmedi", False)

        # 16.5 Admin accessing Admin Users endpoint
        res_admin_users_admin = client.get('/api/admin/users', headers=get_auth_headers(1))
        if res_admin_users_admin.status_code == 200:
            record_result("Admin Yetkilendirme", "Admin -> GET /api/admin/users", "HTTP 200 & Kullanıcı listesi", f"Status 200", "Yüksek", "Yok", True)
        else:
            record_result("Admin Yetkilendirme", "Admin -> GET /api/admin/users", "HTTP 200 dönmeli", f"Status {res_admin_users_admin.status_code}", "Yüksek", res_admin_users_admin.text, False)

    except Exception as e:
        record_result("Rol İzolasyonu", "Rol yetki testleri", "Hata oluşmamalı", f"Hata: {str(e)}", "Kritik", traceback.format_exc(), False)

    # SAVE TEST RESULTS AS JSON
    report_file = os.path.abspath(os.path.join(os.path.dirname(__file__), '../reports/functional_test_results.json'))
    os.makedirs(os.path.dirname(report_file), exist_ok=True)
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"\n--- AUDIT COMPLETED: Total Tests: {len(results)}, Passed: {sum(1 for r in results if r['pass'])}, Failed: {sum(1 for r in results if not r['pass'])} ---")
    print(f"Results saved to: {report_file}")
    return results

if __name__ == '__main__':
    run_tests()
