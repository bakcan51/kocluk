import sys
import os
import unittest

sys.path.insert(0, os.path.abspath('backend'))
from app import app, get_db

class AuthSystemVerificationTest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_01_coach_login_success(self):
        res = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertEqual(data['user']['role'], 'COACH')
        self.assertIn('token', data)

    def test_02_student_login_success(self):
        res = self.client.post('/api/auth/login', json={'username': 'burak.akcan', 'password': 'ogrenci123'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertEqual(data['user']['role'], 'STUDENT')
        self.assertIn('token', data)

    def test_03_admin_login_success(self):
        res = self.client.post('/api/auth/login', json={'username': 'admin', 'password': 'password123'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertEqual(data['user']['role'], 'ADMIN')

    def test_04_wrong_credentials_error_message(self):
        res = self.client.post('/api/auth/login', json={'username': 'invalid_user', 'password': 'wrongpassword'})
        self.assertEqual(res.status_code, 401)
        data = res.get_json()
        self.assertFalse(data['success'])
        self.assertIn('message', data)

    def test_05_student_rbac_protection(self):
        # Student login
        res_s = self.client.post('/api/auth/login', json={'username': 'burak.akcan', 'password': 'ogrenci123'})
        token = res_s.get_json()['token']
        headers = {'Authorization': f'Bearer {token}'}

        # Student trying to call admin endpoint
        res_adm = self.client.get('/api/admin/users', headers=headers)
        self.assertEqual(res_adm.status_code, 403)

    def test_06_coach_cannot_access_unowned_student(self):
        # Coach login (Coach 1: Ümmü Akcan)
        res_c = self.client.post('/api/auth/login', json={'username': 'ummu.akcan', 'password': 'password123'})
        token = res_c.get_json()['token']
        headers = {'Authorization': f'Bearer {token}'}

        # Verify students list only returns coach 1 students
        res_st = self.client.get('/api/students', headers=headers)
        self.assertEqual(res_st.status_code, 200)
        students = res_st.get_json().get('students', [])
        for s in students:
            self.assertEqual(s.get('coach_id'), 1)

    def test_07_data_preservation_integrity(self):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        u_cnt = cursor.fetchone()[0]
        self.assertGreaterEqual(u_cnt, 20)

        cursor.execute("SELECT COUNT(*) FROM students")
        s_cnt = cursor.fetchone()[0]
        self.assertGreaterEqual(s_cnt, 17)
        conn.close()

if __name__ == '__main__':
    unittest.main()
