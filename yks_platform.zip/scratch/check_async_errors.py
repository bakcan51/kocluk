import re

APP_PATH = "/Users/burakakcan/.gemini/antigravity/scratch/yks_platform/frontend/app.js"

with open(APP_PATH, "r", encoding="utf-8") as f:
    lines = f.readlines()

async_funcs = set()
for idx, line in enumerate(lines, 1):
    m = re.finditer(r'async\s+function\s+([a-zA-Z0-9_$]+)', line)
    for match in m:
        async_funcs.add(match.group(1))

# Check for calls to async_funcs inside try blocks without await
unawaited_in_try = []

i = 0
n = len(lines)
while i < n:
    line = lines[i]
    if re.search(r'\btry\s*\{', line):
        try_start = i + 1
        j = i + 1
        brace_depth = 1
        while j < n and brace_depth > 0:
            c_line = lines[j]
            brace_depth += c_line.count('{') - c_line.count('}')
            if re.search(r'\}\s*catch\b', c_line):
                break
            
            clean = re.sub(r'//.*', '', c_line)
            clean = re.sub(r'\'[^\']*\'|"[^"]*"', '', clean)
            
            for af in async_funcs:
                pattern = r'(?<!await\s)(?<!function\s)(?<!async\s)\b' + re.escape(af) + r'\s*\('
                if re.search(pattern, clean):
                    unawaited_in_try.append((try_start, j + 1, af, c_line.strip()))
            j += 1
        i = j
    else:
        i += 1

print(f"Found {len(unawaited_in_try)} unawaited async calls inside try blocks:")
for try_line, call_line, func_name, line_str in unawaited_in_try:
    print(f"L{call_line} (inside try L{try_line}): {func_name} called without await: {line_str}")

